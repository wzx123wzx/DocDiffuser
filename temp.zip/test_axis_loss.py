import numpy as np
import torch
import cv2
import torch.nn.functional as F

device = torch.device("cuda:0")


def get_tps_motion_from_bm(bm, tps_resolution):
    # bm: [b,2,512,512], backward warping flow
    # TPS grid resolution (default same in x and y)
    # target mesh: rigid mesh
    # source mesh: predicted mesh
    # tps motion is (target mesh - source mesh)
    B, _, H, W = bm.shape
    indices_row = np.round(0 + (H - 1) * np.linspace(0, 1, tps_resolution[0] + 1)).astype(np.int32)
    indices_col = np.round(0 + (W - 1) * np.linspace(0, 1, tps_resolution[1] + 1)).astype(np.int32)
    rows = indices_row[:, np.newaxis]
    cols = indices_col[np.newaxis, :]

    base = coords_grid_tensor((H, W)).repeat(B, 1, 1, 1)
    target_mesh = base[:, :, rows, cols]
    source_mesh = bm[:, :, rows, cols]
    tps_motion = source_mesh - target_mesh
    tps_motion[:, 0, :, :] = tps_motion[:, 0, :, :] / (W - 1)
    tps_motion[:, 1, :, :] = tps_motion[:, 1, :, :] / (H - 1)
    return tps_motion


def tps2flow(tps_motion, output_size):
    # tps_motion: tps motion w normalization, [b,2,16,16]
    tps_motion_1 = tps_motion.clone()
    B, _, mesh_h, mesh_w = tps_motion_1.shape
    H, W = output_size
    tps_motion_1[:, 0, :, :] = tps_motion_1[:, 0, :, :] * (W - 1)
    tps_motion_1[:, 1, :, :] = tps_motion_1[:, 1, :, :] * (H - 1)

    indices_row = np.round(0 + (H - 1) * np.linspace(0, 1, mesh_h)).astype(np.int32)
    indices_col = np.round(0 + (W - 1) * np.linspace(0, 1, mesh_w)).astype(np.int32)
    rows = indices_row[:, np.newaxis]
    cols = indices_col[np.newaxis, :]
    base = coords_grid_tensor((H, W)).repeat(B, 1, 1, 1)
    target = base[:, :, rows, cols]
    source = target + tps_motion_1
    # source_ref = np.load('source.npy')
    # target_ref = np.load('target.npy')
    target = target.permute(0, 2, 3, 1)
    source = source.permute(0, 2, 3, 1)

    # temp_source = source.cpu().detach().numpy()
    # temp_target = target.cpu().detach().numpy()
    def get_norm_mesh(mesh, height, width):
        B, _, _, _ = mesh.shape
        mesh_w = mesh[..., 0] * 2. / float(width) - 1.
        mesh_h = mesh[..., 1] * 2. / float(height) - 1.
        norm_mesh = torch.stack([mesh_w, mesh_h], 3)  # bs*(grid_h+1)*(grid_w+1)*2

        return norm_mesh.reshape([B, -1, 2])  # bs*-1*2

    def _meshgrid(height, width, source):
        x_t = torch.matmul(torch.ones([height, 1]), torch.unsqueeze(torch.linspace(-1.0, 1.0, width), 0)).to(
            source.device)
        y_t = torch.matmul(torch.unsqueeze(torch.linspace(-1.0, 1.0, height), 1), torch.ones([1, width])).to(
            source.device)

        x_t_flat = x_t.reshape([1, 1, -1])
        y_t_flat = y_t.reshape([1, 1, -1])

        num_batch = source.size()[0]
        px = torch.unsqueeze(source[:, :, 0], 2).to(source.device)  # [bn, pn, 1]
        py = torch.unsqueeze(source[:, :, 1], 2).to(source.device)  # [bn, pn, 1]

        d2 = torch.square(x_t_flat - px) + torch.square(y_t_flat - py)
        r = d2 * torch.log(d2 + 1e-6)  # [bn, pn, h*w]
        x_t_flat_g = x_t_flat.expand(num_batch, -1, -1)  # [bn, 1, h*w]
        y_t_flat_g = y_t_flat.expand(num_batch, -1, -1)  # [bn, 1, h*w]
        ones = torch.ones_like(x_t_flat_g).to(source.device)  # [bn, 1, h*w]

        grid = torch.cat((ones, x_t_flat_g, y_t_flat_g, r), 1)  # [bn, 3+pn, h*w]

        return grid

    def _transform(T, source, out_size):
        num_batch, _, _ = source.shape

        out_height, out_width = out_size[0], out_size[1]
        grid = _meshgrid(out_height, out_width, source)  # [bn, 3+pn, h*w]

        # transform A x (1, x_t, y_t, r1, r2, ..., rn) -> (x_s, y_s)
        # [bn, 2, pn+3] x [bn, pn+3, h*w] -> [bn, 2, h*w]
        T_g = torch.matmul(T, grid)
        x_s = T_g[:, 0, :]
        y_s = T_g[:, 1, :]
        x_s_flat = x_s.reshape([-1])
        y_s_flat = y_s.reshape([-1])

        # input_transformed = _interpolate(input_dim, x_s_flat, y_s_flat, out_size)
        # output = input_transformed.reshape([num_batch, out_height, out_width, num_channels])
        # output = output.permute(0, 3, 1, 2)

        flow_x = x_s_flat.reshape([num_batch, -1])
        flow_y = y_s_flat.reshape([num_batch, -1])
        tps_flow = torch.stack([flow_x, flow_y], 1).reshape([num_batch, 2, out_height, out_width])

        return tps_flow

    def _solve_system(source, target):
        num_batch = source.size()[0]
        num_point = source.size()[1]

        np.set_printoptions(precision=8)

        ones = torch.ones(num_batch, num_point, 1).float().to(source.device)

        p = torch.cat([ones, source], 2)  # [bn, pn, 3]

        p_1 = p.reshape([num_batch, -1, 1, 3])  # [bn, pn, 1, 3]
        p_2 = p.reshape([num_batch, 1, -1, 3])  # [bn, 1, pn, 3]
        d2 = torch.sum(torch.square(p_1 - p_2), 3)  # p1 - p2: [bn, pn, pn, 3]   final output: [bn, pn, pn]

        r = d2 * torch.log(d2 + 1e-6)  # [bn, pn, pn]

        zeros = torch.zeros(num_batch, 3, 3).float().to(source.device)

        W_0 = torch.cat((p, r), 2)  # [bn, pn, 3+pn]
        W_1 = torch.cat((zeros, p.permute(0, 2, 1)), 2)  # [bn, 3, pn+3]
        W = torch.cat((W_0, W_1), 1)  # [bn, pn+3, pn+3]

        W_inv = torch.inverse(W.type(torch.float64).cpu()).cuda()
        # W_inv = torch.inverse(W.type(torch.float64))

        zeros2 = torch.zeros(num_batch, 3, 2).to(source.device)

        tp = torch.cat((target, zeros2), 1)  # [bn, pn+3, 2]

        T = torch.matmul(W_inv, tp.type(torch.float64))  # [bn, pn+3, 2]
        T = T.permute(0, 2, 1)  # [bn, 2, pn+3]

        return T.type(torch.float32)

    norm_target_mesh = get_norm_mesh(target, output_size[0], output_size[1])
    norm_source_mesh = get_norm_mesh(source, output_size[0], output_size[1])
    # norm_target_mesh_ref = np.load('norm_target_mesh.npy')
    # norm_source_mesh_ref = np.load('norm_source_mesh.npy')
    # temp_norm_source_mesh = norm_source_mesh.cpu().detach().numpy()
    # temp_norm_target_mesh = norm_target_mesh.cpu().detach().numpy()
    T = _solve_system(norm_target_mesh, norm_source_mesh)
    # temp_T = T.cpu().detach().numpy()
    # T_ref = np.load('T.npy')
    tps_flow = _transform(T, norm_target_mesh, output_size)
    # temp_tps_flow = tps_flow.cpu().detach().numpy()
    # tps_flow_ref = np.load('tps_flow.npy')
    return tps_flow, T, source, target


def coords_grid_tensor(perturbed_img_shape):
    im_x, im_y = np.mgrid[0:perturbed_img_shape[0] - 1:complex(perturbed_img_shape[0]),
                 0:perturbed_img_shape[1] - 1:complex(perturbed_img_shape[1])]
    coords = np.stack((im_y, im_x), axis=2)
    coords = torch.from_numpy(coords).float().permute(2, 0, 1).to(device)
    return coords.unsqueeze(0)


def get_norm_mesh(mesh, height, width):
    B, _, _, _ = mesh.shape
    mesh_w = mesh[..., 0] * 2. / float(width) - 1.
    mesh_h = mesh[..., 1] * 2. / float(height) - 1.
    norm_mesh = torch.stack([mesh_w, mesh_h], 3)  # bs*(grid_h+1)*(grid_w+1)*2

    return norm_mesh.reshape([B, -1, 2])  # bs*-1*2


bm_file_path = '/data/wzx/dataset/Doc3d/bm/1/1_9_5-pp_Page_217-UL00001.npy'
img_file_path = '/data/wzx/dataset/Doc3d/img/1/1_9_5-pp_Page_217-UL00001.png'

bm = np.load(bm_file_path)
bm = bm.transpose((0, 2, 1))

img = cv2.imread(img_file_path).astype(np.float32)

bm_tensor = torch.tensor(bm).unsqueeze(0).to(device)  # B*H*W*2,torch.float32
img_tensor = torch.tensor(img).unsqueeze(0).to(device)  # B*3*H*W,torch.float32

tps_motion = get_tps_motion_from_bm(bm_tensor, [7, 7])
tps_flow, T, source, target = tps2flow(tps_motion, [448, 448])

zeros2 = torch.zeros(tps_flow.shape[0], 3, 2).to(source.device)
norm_source_mesh = get_norm_mesh(source, 448, 448)
tp = torch.cat((norm_source_mesh, zeros2), 1)  # [bn, pn+3, 2]
tp_inv = torch.linalg.pinv(tp)
temp = torch.bmm(tp_inv, tp)
warped_source = torch.bmm(T.permute(0, 2, 1), tp_inv)
temp = warped_source.cpu().numpy()
print(temp)
img_transformed = F.grid_sample(img_tensor.permute(0, 3, 1, 2), tps_flow.permute(0, 2, 3, 1), mode='bilinear',
                                align_corners=True)
cv2.imwrite('img_tps_transformed.jpg', img_transformed.squeeze().permute(1, 2, 0).cpu().numpy())
print('done')
