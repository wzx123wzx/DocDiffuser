import torch


class dir:
    workspace_dir = 'checkpoints'  # Base directory for saving network checkpoints.
    tensorboard_dir = workspace_dir  # Directory for tensorboard files.
    pretrained_networks = workspace_dir
    pre_trained_models_dir = workspace_dir + "/backup"


class train:
    image_size = [512, 512]
    cuda_idx = 0
    device = torch.device("cuda:{}".format(cuda_idx))
    dataset_name = 'doc3d_grid'
    if dataset_name == 'doc_debug':
        train_dataset_path = '/home/share/train_bug3'
        time_variant = False
    elif dataset_name == 'uvdoc':
        # train_dataset_path = '/data/wzx/dataset/UVDoc_final'
        train_dataset_path = 'E:/Dataset/UVDoc/UVDoc_final'
        time_variant = True
        grid3d_normalization = (0.11433014, -0.12551452, 0.12401487, -0.12401487, 0.1952378, -0.1952378)
    elif dataset_name == 'doc3d':
        train_dataset_path = '/data/wzx/dataset/Doc3d'
        time_variant = True
    elif dataset_name == 'doc3d_grid':
        train_dataset_path = 'E:/Dataset/Doc3D/Doc3d'
        time_variant = True
        grid3d_normalization = (1.2539363, -1.2442188, 1.2396319, -1.2289206, 0.6436657, -0.67492497)

    train_mode = 'stage_1_dit_cross'
    iter = True
    train_VGG = True
    use_gt_mask = False
    use_line_mask = True
    use_init_flow = False
    lr = 1e-4
    batch_size = 4
    n_threads = 4
    schedule_sampler = 'uniform'  # 'uniform' 'multi' 'fixed'
    weight_decay = 0.0
    lr_anneal_steps = 0
    microbatch = -1
    ema_rate = 0.9999
    use_fp16 = False
    fp16_scale_growth = 0.001
    visualize = True  # Set True, if you want qualitative results.
    use_sr_net = False
    clip_denoised = True

    use_axis_loss = False
    use_mask_loss = False
    use_inter_loss = False
    use_depth_loss = False

    w1 = 1.0
    w2 = 1.0
    w3 = 1.0
    w4 = 1.0
    w5 = 1.0

class eval:
    cuda_idx = 1
    device = torch.device("cuda:{}".format(cuda_idx))
    dataset_name = "docunet"
    if dataset_name == 'docunet':
        eval_dataset_path = '/data/wzx/dataset/DocUNet/crop'
    elif dataset_name == 'docunet':
        eval_dataset_path = '/data/wzx/dataset/DocUNet/crop'
    elif dataset_name == 'docunet':
        eval_dataset_path = '/data/wzx/dataset/DocUNet/crop'

    experiment_name = "test"


class model:
    image_size = 64
    embedding_cond_size = 64
    update_feat_size = [64, 64]
    tps_resolution = 8
    radius = 4
    flow_size = (64, 64)
    num_channels = 128
    num_res_blocks = 3
    num_heads = 4
    num_heads_upsample = -1
    attention_resolutions = "16,8"
    dropout = 0.0
    learn_sigma = False
    sigma_small = False
    class_cond = False
    diffusion_steps = 3  # why here diffusion step is only 3???
    noise_schedule = 'cosine'
    use_kl = False
    predict_xstart = True  # pred eps/xstart
    predict_res = False  # predict absolute tps motion or residual tps motion (add the tps motion of x_{t+1} in model forward), set false is stable
    rescale_timesteps = True
    rescale_learned_sigmas = True
    use_checkpoint = False
    use_scale_shift_norm = True
    clip_denoised = False
    num_samples = 10000
    val_batch_size = 1
    use_ddim = False
    n_batch = 1  # multiple hypotheses
    interpolation_mode = 'bilinear'
    use_3dtps = True
    if use_3dtps:
        in_channels = 3
    else:
        in_channels = 2


class log:
    log_interval = 40
    save_interval = 4000
    tb_interval = 40
    resume_step = 0  # 152000 #1390000
    resume_checkpoint = None
    nbr_objects = 4
    min_area_objects = 1300
    compute_object_reprojection_mask = True
    initial_pretrained_model = None
    data_dir = ''


class resume:
    model_path = 'checkpoints/model020000.pt'
    seg_model_path = "checkpoints/seg.pth"
    line_seg_model_path = 'checkpoints/line_model2.pth'
    new_seg_model_path = 'checkpoints/seg_model.pth'
    timestep_respacing = ''
