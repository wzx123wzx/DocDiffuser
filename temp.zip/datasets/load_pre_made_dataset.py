import glob
import os.path

from datasets.listdataset import ListDataset, Aug_ListDataset, Aug_Doc3d_ListDataset, Aug_Doc3d_ListDataset_new, \
    Aug_Doc3d_ListDataset_TPSGen, Aug_UVDoc_ListDataset_TPSGen, Aug_Doc3dGrid_ListDataset_TPSGen
from datasets.util import split2list
import json


def make_doc3d_dataset_list(dir, split=None):
    dataset_list = []
    for sample_name in os.listdir(dir):
        # flow_map = os.path.join(dir, os.path.basename(flow_map))
        # root_filename = os.path.basename(flow_map)[:-9]
        img = os.path.join(dir, sample_name, 'img.png')  # source image
        flow_map = os.path.join(dir, sample_name, 'bm.mat')  # flow_map
        abd = os.path.join(dir, sample_name, 'recon.png')  # recon
        # img2 = os.path.join(dir, root_filename + '_img_2.jpg') # target image
        dataset_list.append([img, flow_map, abd])

    return split2list(dataset_list, split, default_split=0.97)


# def make_doc3d_dataset_list_new(dir, split=None):
#     # edit for my dataset folder structure
#     dataset_list = []
#     for sample_name in os.listdir(os.path.join(dir, 'img')):
#         sample_name = sample_name[:-4]
#         img = '{}/img/{}.png'.format(dir, sample_name)  # source image
#         flow_map = '{}/bm/{}.npy'.format(dir, sample_name)   # flow_map
#         # abd = '{}/alb/{}.png'.format(dir, sample_name)   # recon
#         abd = '{}/recon/{}.png'.format(dir, '{}chess48{}'.format(sample_name[:-4], sample_name[-4:]))
#         dataset_list.append([img, flow_map, abd])

# return split2list(dataset_list, split, default_split=0.97)

# def make_doc3d_dataset_list_new(dir, split=None):
#     # edit for my dataset folder structure
#     sub_dataset_list = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17',
#                         '18', '19', '20', '21']
#     dataset_list = []
#     for sample_name in os.listdir('{}/img'.format(dir)):
#         sample_name = sample_name[:-4]
#         img = '{}/img/{}.png'.format(dir, sample_name)  # source image
#         flow_map = '{}/bm/{}.npy'.format(dir, sample_name)  # flow_map
#         abd = '{}/recon/{}.png'.format(dir, '{}chess48{}'.format(sample_name[:-4], sample_name[-4:]))
#         dataset_list.append([img, flow_map, abd])
#
#     return split2list(dataset_list, split, default_split=0.97)

def make_doc3d_dataset_list_new(dir, split=None):
    # edit for my dataset folder structure
    sub_dataset_list = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17',
                        '18', '19', '20', '21']
    dataset_list = []
    for idx in range(1, 22):
        for sample_name in os.listdir('{}/img/{}'.format(dir, idx)):
            sample_name = sample_name[:-4]
            img = '{}/img/{}/{}.png'.format(dir, idx, sample_name)  # source image
            flow_map = '{}/bm/{}/{}.npy'.format(dir, idx, sample_name)  # flow_map
            # abd = '{}/alb/{}.png'.format(dir, sample_name)   # recon
            abd = '{}/recon/{}/{}.png'.format(dir, idx, '{}chess48{}'.format(sample_name[:-4], sample_name[-4:]))
            dataset_list.append([img, flow_map, abd])

    return split2list(dataset_list, split, default_split=0.97)

def make_doc3dGrid_dataset_list(dir, split=None):
    # edit for my dataset folder structure
    sub_dataset_list = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17',
                        '18', '19', '20', '21']
    dataset_list = []
    # for idx in range(1, 22):
    for idx in range(1,2):
        for sample_name in os.listdir('{}/img/{}'.format(dir, idx)):
            sample_name = sample_name[:-4]
            img = '{}/img/{}/{}.png'.format(dir, idx, sample_name)  # source image
            flow_map = '{}/bm/{}/{}.npy'.format(dir, idx, sample_name)  # flow_map
            # abd = '{}/alb/{}.png'.format(dir, sample_name)   # recon
            abd = '{}/recon/{}/{}.png'.format(dir, idx, '{}chess48{}'.format(sample_name[:-4], sample_name[-4:]))
            grid2d = '{}/grid2d/{}/{}.mat'.format(dir, idx, sample_name)
            grid3d = '{}/grid3d/{}/{}.mat'.format(dir, idx, sample_name)
            dataset_list.append([img, flow_map, abd, grid2d, grid3d])

    return split2list(dataset_list, split, default_split=0.97)

def make_uvdoc_dataset_list(dir, split=None):
    # edit for my dataset folder structure
    dataset_list = []
    for sample in os.listdir('{}/metadata_sample'.format(dir)):
        with open('{}/metadata_sample/{}'.format(dir, sample), 'r', encoding='utf-8') as file:
            data = json.load(file)

            texture_path = '{}/textures_ori/{}'.format(dir, data['texture_name'])
            background_path = '{}/background/{}'.format(dir, data['background_name'])

            geom_name = '{}/metadata_geom/{}'.format(dir, data['geom_name'])
            img_path = '{}/img/{}.png'.format(dir, data['sample_id'])
            warped_texture_path = '{}/warped_textures/{}.png'.format(dir, data['sample_id'])
            grid2d_path = '{}/grid2d/{}.mat'.format(dir, data['geom_name'])
            grid3d_path = '{}/grid3d/{}.mat'.format(dir, data['geom_name'])
            mask_path = '{}/seg/{}.mat'.format(dir, data['geom_name'])
            uv_path = '{}/uvmap/{}.mat'.format(dir, data['geom_name'])
            wc_path = '{}/wc/{}.exr'.format(dir, data['geom_name'])
            bm_path = '{}/norm_bm/{}.npy'.format(dir, data['sample_id'])
            dataset_list.append(
                [texture_path, background_path, img_path, warped_texture_path, grid2d_path, grid3d_path, mask_path,
                 uv_path, wc_path, bm_path])

    return split2list(dataset_list, split, default_split=0.97)

def make_uvdoc_dataset_list_new(dir, split=None):
    # edit for my dataset folder structure
    dataset_list = []
    for sample in os.listdir('{}/metadata_sample'.format(dir)):
        with open('{}/metadata_sample/{}'.format(dir, sample), 'r', encoding='utf-8') as file:
            data = json.load(file)

            texture_path = '{}/textures_ori/{}'.format(dir, data['texture_name'])
            background_path = '{}/background/{}'.format(dir, data['background_name'])

            geom_name = '{}/metadata_geom/{}'.format(dir, data['geom_name'])
            img_path = '{}/img/{}.png'.format(dir, data['sample_id'])
            warped_texture_path = '{}/warped_textures/{}.png'.format(dir, data['sample_id'])
            grid2d_path = '{}/grid2d/{}.mat'.format(dir, data['geom_name'])
            grid3d_path = '{}/grid3d/{}.mat'.format(dir, data['geom_name'])
            mask_path = '{}/seg/{}.mat'.format(dir, data['geom_name'])
            uv_path = '{}/uvmap/{}.mat'.format(dir, data['geom_name'])
            wc_path = '{}/wc/{}.exr'.format(dir, data['geom_name'])
            bm_path = '{}/norm_bm/{}.npy'.format(dir, data['sample_id'])
            dataset_list.append(
                [texture_path, background_path, img_path, warped_texture_path, grid2d_path, grid3d_path, mask_path,
                 uv_path, wc_path, bm_path])

    return split2list(dataset_list, split, default_split=0.97)

def make_doc_dataset_list(dir, split=None):
    dataset_list = []
    for sample_name in os.listdir(dir):
        # flow_map = os.path.join(dir, os.path.basename(flow_map))
        # root_filename = os.path.basename(flow_map)[:-9]
        img = os.path.join(dir, sample_name, 'warped_document.png')  # source image
        flow_map = os.path.join(dir, sample_name, 'warped_BM.npz')  # flow_map
        abd = os.path.join(dir, sample_name, 'warped_recon.png')  # recon
        # img2 = os.path.join(dir, root_filename + '_img_2.jpg') # target image
        dataset_list.append([img, flow_map, abd])

    return split2list(dataset_list, split, default_split=0.97)


def make_dataset(dir, get_mapping, split=None, dataset_name=None):
    """
    Will search for triplets that go by the pattern '[name]_img1.ppm  [name]_img2.ppm  in folder images and
      [name]_flow.flo' in folder flow """
    images = []
    if get_mapping:  # false
        flow_dir = 'mapping'
        # flow_dir is actually mapping dir in that case, it is always normalised to [-1,1]
    else:
        flow_dir = 'flow'
    image_dir = 'images'

    # Make sure that the folders exist
    if not os.path.isdir(dir):
        raise ValueError("the training directory path that you indicated does not exist ! ")
    if not os.path.isdir(os.path.join(dir, flow_dir)):
        raise ValueError("the training directory path that you indicated does not contain the flow folder ! "
                         "Check your directories.")
    if not os.path.isdir(os.path.join(dir, image_dir)):
        raise ValueError("the training directory path that you indicated does not contain the images folder ! "
                         "Check your directories.")

    for flow_map in sorted(glob.glob(os.path.join(dir, flow_dir, '*_flow.flo'))):
        flow_map = os.path.join(flow_dir, os.path.basename(flow_map))
        root_filename = os.path.basename(flow_map)[:-9]
        img1 = os.path.join(image_dir, root_filename + '_img_1.jpg')  # source image
        img2 = os.path.join(image_dir, root_filename + '_img_2.jpg')  # target image
        if not (os.path.isfile(os.path.join(dir, img1)) or os.path.isfile(os.path.join(dir, img2))):
            continue
        if dataset_name is not None:  # false
            images.append([[os.path.join(dataset_name, img1),
                            os.path.join(dataset_name, img2)],
                           os.path.join(dataset_name, flow_map)])
        else:  # true
            images.append([[img1, img2], flow_map])
    return split2list(images, split, default_split=0.97)


def assign_default(default_dict, dict):
    if dict is None:
        dall = default_dict
    else:
        dall = {}
        dall.update(default_dict)
        dall.update(dict)
    return dall


def Doc_Dataset(root, source_image_transform=None, target_image_transform=None, flow_transform=None,
                co_transform=None, split=None, get_mapping=False, compute_mask_zero_borders=False,
                add_discontinuity=False, min_nbr_perturbations=5, max_nbr_perturbations=6,
                parameters_v2=None):
    """
    Builds a dataset from existing image pairs and corresponding ground-truth flow fields and optionally add
    some flow perturbations.
    Args:
        root: path to root folder
        source_image_transform: image transformations to apply to source images
        target_image_transform: image transformations to apply to target images
        flow_transform: flow transformations to apply to ground-truth flow fields
        co_transform: transformations to apply to both images and ground-truth flow fields
        split: split (float) between training and testing, 0 means all pairs are in test_dataset
        get_mapping: output mapping instead of flow in __getittem__ ?
        compute_mask_zero_borders: output mask of zero borders ?
        add_discontinuity: add discontinuity to image pairs and corresponding ground-truth flow field ?
        min_nbr_perturbations:
        max_nbr_perturbations:
        parameters_v2: parameters of v2

    Returns:
        train_dataset
        test_dataset

    """
    train_list, test_list = make_doc_dataset_list(root, split)  # get list [[sample1],[sample2],...]
    train_dataset = ListDataset(root, train_list, source_image_transform=source_image_transform,
                                target_image_transform=target_image_transform,
                                flow_transform=flow_transform, co_transform=co_transform, get_mapping=get_mapping,
                                compute_mask_zero_borders=compute_mask_zero_borders)
    test_dataset = ListDataset(root, test_list, source_image_transform=source_image_transform,
                               target_image_transform=target_image_transform,
                               flow_transform=flow_transform, co_transform=co_transform, get_mapping=get_mapping,
                               compute_mask_zero_borders=compute_mask_zero_borders)
    return train_dataset, test_dataset


def Aug_Doc_Dataset(root, source_image_transform=None, target_image_transform=None, flow_transform=None,
                    co_transform=None, split=None, get_mapping=False, compute_mask_zero_borders=False,
                    add_discontinuity=False, min_nbr_perturbations=5, max_nbr_perturbations=6,
                    parameters_v2=None):
    train_list, test_list = make_doc_dataset_list(root, split)  # get list [[sample1],[sample2],...]
    train_dataset = Aug_ListDataset(root, train_list, source_image_transform=source_image_transform,
                                    target_image_transform=target_image_transform,
                                    flow_transform=flow_transform, co_transform=co_transform, get_mapping=get_mapping,
                                    compute_mask_zero_borders=compute_mask_zero_borders)
    test_dataset = Aug_ListDataset(root, test_list, source_image_transform=source_image_transform,
                                   target_image_transform=target_image_transform,
                                   flow_transform=flow_transform, co_transform=co_transform, get_mapping=get_mapping,
                                   compute_mask_zero_borders=compute_mask_zero_borders)
    return train_dataset, test_dataset


def Doc3d_Dataset(root, source_image_transform=None, target_image_transform=None, flow_transform=None,
                  co_transform=None, split=None, get_mapping=False, compute_mask_zero_borders=False,
                  add_discontinuity=False, min_nbr_perturbations=5, max_nbr_perturbations=6,
                  parameters_v2=None):
    # train_list, test_list = make_doc3d_dataset_list(root, split) # get list [[sample1],[sample2],...]
    train_list, test_list = make_doc3d_dataset_list_new(root, split)
    train_dataset = Aug_Doc3d_ListDataset_new(root, train_list, source_image_transform=source_image_transform,
                                              target_image_transform=target_image_transform,
                                              flow_transform=flow_transform, co_transform=co_transform,
                                              get_mapping=get_mapping,
                                              compute_mask_zero_borders=compute_mask_zero_borders)
    test_dataset = Aug_Doc3d_ListDataset_new(root, test_list, source_image_transform=source_image_transform,
                                             target_image_transform=target_image_transform,
                                             flow_transform=flow_transform, co_transform=co_transform,
                                             get_mapping=get_mapping,
                                             compute_mask_zero_borders=compute_mask_zero_borders)
    return train_dataset, test_dataset


def Doc3d_Dataset_TPSGen(root, source_image_transform=None, target_image_transform=None, flow_transform=None,
                         co_transform=None, split=None, get_mapping=False, compute_mask_zero_borders=False,
                         add_discontinuity=False, min_nbr_perturbations=5, max_nbr_perturbations=6,
                         parameters_v2=None):
    # get original dataset path
    # train_list, test_list = make_doc3d_dataset_list(root, split) # get list [[sample1],[sample2],...]
    train_list, test_list = make_doc3d_dataset_list_new(root, split)
    train_dataset = Aug_Doc3d_ListDataset_TPSGen(root, train_list, source_image_transform=source_image_transform,
                                                 target_image_transform=target_image_transform,
                                                 flow_transform=flow_transform, co_transform=co_transform,
                                                 get_mapping=get_mapping,
                                                 compute_mask_zero_borders=compute_mask_zero_borders)
    test_dataset = Aug_Doc3d_ListDataset_TPSGen(root, test_list, source_image_transform=source_image_transform,
                                                target_image_transform=target_image_transform,
                                                flow_transform=flow_transform, co_transform=co_transform,
                                                get_mapping=get_mapping,
                                                compute_mask_zero_borders=compute_mask_zero_borders)

    return train_dataset, test_dataset


def UVDoc_Dataset_TPSGen(root, source_image_transform=None, target_image_transform=None, flow_transform=None,
                         co_transform=None, split=None, get_mapping=False, compute_mask_zero_borders=False,
                         add_discontinuity=False, min_nbr_perturbations=5, max_nbr_perturbations=6,
                         parameters_v2=None):
    # get original dataset path
    # train_list, test_list = make_doc3d_dataset_list(root, split) # get list [[sample1],[sample2],...]
    train_list, test_list = make_uvdoc_dataset_list(root, split)
    train_dataset = Aug_UVDoc_ListDataset_TPSGen(root, train_list, source_image_transform=source_image_transform,
                                                 target_image_transform=target_image_transform,
                                                 flow_transform=flow_transform, co_transform=co_transform,
                                                 get_mapping=get_mapping,
                                                 compute_mask_zero_borders=compute_mask_zero_borders)
    test_dataset = Aug_UVDoc_ListDataset_TPSGen(root, test_list, source_image_transform=source_image_transform,
                                                target_image_transform=target_image_transform,
                                                flow_transform=flow_transform, co_transform=co_transform,
                                                get_mapping=get_mapping,
                                                compute_mask_zero_borders=compute_mask_zero_borders)

    return train_dataset, test_dataset

def Doc3dGrid_Dataset_TPSGen(root, source_image_transform=None, target_image_transform=None, flow_transform=None,
                         co_transform=None, split=None, get_mapping=False, compute_mask_zero_borders=False,
                         add_discontinuity=False, min_nbr_perturbations=5, max_nbr_perturbations=6,
                         parameters_v2=None):
    # get original dataset path
    # train_list, test_list = make_doc3d_dataset_list(root, split) # get list [[sample1],[sample2],...]
    train_list, test_list = make_doc3dGrid_dataset_list(root, split)
    train_dataset = Aug_Doc3dGrid_ListDataset_TPSGen(root, train_list, source_image_transform=source_image_transform,
                                                 target_image_transform=target_image_transform,
                                                 flow_transform=flow_transform, co_transform=co_transform,
                                                 get_mapping=get_mapping,
                                                 compute_mask_zero_borders=compute_mask_zero_borders)
    test_dataset = Aug_Doc3dGrid_ListDataset_TPSGen(root, test_list, source_image_transform=source_image_transform,
                                                target_image_transform=target_image_transform,
                                                flow_transform=flow_transform, co_transform=co_transform,
                                                get_mapping=get_mapping,
                                                compute_mask_zero_borders=compute_mask_zero_borders)

    return train_dataset, test_dataset
