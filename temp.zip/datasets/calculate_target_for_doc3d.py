import numpy as np
import torch
import torch.nn.functional as F
import os
import json
import cv2
import h5py
import os
device = torch.device("cuda:1")

def make_doc3d_dataset_list_new(dir):
    # edit for my dataset folder structure
    sub_dataset_list = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21']
    dataset_list = []
    for idx in range(1,22):
        for sample_name in os.listdir('{}/img/{}'.format(dir, idx)):
            sample_name = sample_name[:-4]
            img = '{}/img/{}/{}.png'.format(dir, idx, sample_name)  # source image
            flow_map = '{}/bm/{}/{}.npy'.format(dir, idx, sample_name)   # flow_map
            # abd = '{}/alb/{}.png'.format(dir, sample_name)   # recon
            abd = '{}/recon/{}/{}.png'.format(dir, idx, '{}chess48{}'.format(sample_name[:-4], sample_name[-4:]))
            dataset_list.append([img, flow_map, abd])

    return dataset_list

def get_norm_target_mesh(tps_resolution, img_resolution,dataset_name='doc3d',):
    H, W = img_resolution
    grid_h = 512
    grid_w = 512
    if dataset_name == 'doc3d':
        grid_h = 512
        grid_w = 512
    elif dataset_name == 'uvdoc':
        grid_h = 89
        grid_w = 61

    B = 1
    grid_indices_row = np.round(0 + (grid_h - 1) * np.linspace(0, 1, tps_resolution[0])).astype(np.int32)
    grid_indices_col = np.round(0 + (grid_w - 1) * np.linspace(0, 1, tps_resolution[1])).astype(np.int32)
    grid_rows = grid_indices_row[:, np.newaxis]
    grid_cols = grid_indices_col[np.newaxis, :]

    rows = np.linspace(0, H - 1, num=grid_h, dtype=np.float32)
    cols = np.linspace(0, W - 1, num=grid_w, dtype=np.float32)
    row_grid, col_grid = np.meshgrid(cols, rows, indexing='xy')
    base = np.stack([row_grid, col_grid], axis=0)
    base = torch.from_numpy(base[np.newaxis, ...]).repeat(B, 1, 1, 1)

    target_mesh = base[:, :, grid_rows, grid_cols]

    norm_target_mesh = target_mesh.clone()
    norm_target_mesh = norm_target_mesh.permute(0,2,3,1)
    mesh_w = norm_target_mesh[..., 0] * 2. / W - 1
    mesh_h = norm_target_mesh[..., 1] * 2. / H - 1
    norm_target_mesh = torch.stack([mesh_w, mesh_h], dim=3)  # [b,16,16,2],[-1,1]
    return norm_target_mesh.to(dtype=torch.float32).to(device)

def load_flo_TPSGen(path):
    # 3D array (columns, rows, bands), without normalization
    bm = np.load(path)
    bm = bm * (511 / 447) - 1.2  # scale to 512*512 and correct the raw data bias (according to the DvD author)
    bm0 = cv2.resize(bm[0, :, :], (512, 512))
    bm1 = cv2.resize(bm[1, :, :], (512, 512))
    bm = np.stack([bm0, bm1], axis=-1).transpose((1, 0, 2))
    return bm
def get_tps_motion_from_grid2d(grid2d, tps_resolution, img_resolution):
    # grid2d: [b,2,89,61], gt source mesh
    # TPS grid resolution (default same in x and y)
    # target mesh: rigid mesh
    # source mesh: predicted mesh
    # tps motion is (target mesh - source mesh)
    H, W = img_resolution
    B, _, grid_h, grid_w = grid2d.shape

    grid_indices_row = np.round(0 + (grid_h - 1) * np.linspace(0, 1, tps_resolution[0])).astype(np.int32)
    grid_indices_col = np.round(0 + (grid_w - 1) * np.linspace(0, 1, tps_resolution[1])).astype(np.int32)
    grid_rows = grid_indices_row[:, np.newaxis]
    grid_cols = grid_indices_col[np.newaxis, :]
    source_mesh = grid2d[:, :, grid_rows, grid_cols]

    rows = np.linspace(0, H - 1, num=grid_h, dtype=np.float32)
    cols = np.linspace(0, W - 1, num=grid_w, dtype=np.float32)
    row_grid, col_grid = np.meshgrid(cols, rows, indexing='xy')
    base = np.stack([row_grid, col_grid], axis=0)
    base = torch.from_numpy(base[np.newaxis, ...]).repeat(B, 1, 1, 1).to(grid2d.device)

    # feat_rows = np.linspace(0, settings.model.update_feat_size[0] - 1, num=grid_h, dtype=np.float32)
    # feat_cols = np.linspace(0, settings.model.update_feat_size[1] - 1, num=grid_w, dtype=np.float32)
    # feat_row_grid, feat_col_grid = np.meshgrid(feat_cols, feat_rows, indexing='xy')
    # feat_base = np.stack([feat_row_grid, feat_col_grid], axis=0)
    # feat_base = torch.from_numpy(feat_base[np.newaxis, ...]).repeat(B, 1, 1, 1).to(grid2d.device)

    target_mesh = base[:, :, grid_rows, grid_cols]
    # feat_target_mesh = feat_base[:, :, grid_rows, grid_cols]

    tps_motion = source_mesh - target_mesh
    tps_motion[:, 0, :, :] = tps_motion[:, 0, :, :] / (W - 1)
    tps_motion[:, 1, :, :] = tps_motion[:, 1, :, :] / (H - 1)

    norm_target_mesh = target_mesh[0].unsqueeze(0).clone()
    norm_target_mesh = norm_target_mesh.permute(0,2,3,1)
    mesh_w = norm_target_mesh[..., 0] * 2. / W - 1
    mesh_h = norm_target_mesh[..., 1] * 2. / H - 1
    norm_target_mesh = torch.stack([mesh_w, mesh_h], dim=3)  # [b,16,16,2],[-1,1]
    return source_mesh.permute(0,2,3,1).to(dtype=torch.float32), norm_target_mesh.to(dtype=torch.float32), tps_motion.to(dtype=torch.float32)

def tps2flow(tps_motion, output_size, norm_target, solve_inv=False):
    if tps_motion.shape[0] != norm_target.shape[0]:
        target = norm_target.repeat(tps_motion.shape[0], 1, 1, 1).clone()
    else:
        target = norm_target.clone()
    # tps_motion: tps motion w normalization, [b,2,16,16]
    tps_motion_1 = tps_motion.clone()
    B, _, mesh_h, mesh_w = tps_motion_1.shape
    H, W = output_size
    tps_motion_1[:, 0, :, :] = tps_motion_1[:, 0, :, :] * (W - 1)
    tps_motion_1[:, 1, :, :] = tps_motion_1[:, 1, :, :] * (H - 1)


    target[..., 0] = (target[..., 0] + 1) / 2 * (W - 1)
    target[..., 1] = (target[..., 1] + 1) / 2 * (H - 1)
    target = target.permute(0,3,1,2)
    source = target + tps_motion_1
    target = target.permute(0, 2, 3, 1)
    source = source.permute(0, 2, 3, 1)

    def get_norm_mesh(mesh, height, width):
        B, _, _, _ = mesh.shape
        mesh_w = mesh[..., 0] * 2. / float(width) - 1.
        mesh_h = mesh[..., 1] * 2. / float(height) - 1.
        norm_mesh = torch.stack([mesh_w, mesh_h], 3)  # bs*(grid_h+1)*(grid_w+1)*2

        return norm_mesh.reshape([B, -1, 2])  # bs*-1*2

    def _meshgrid(height, width, source):
        x_t = torch.matmul(torch.ones([height, 1]), torch.unsqueeze(torch.linspace(-1.0, 1.0, width), 0)).to(
            source.device)
        y_t = torch.matmul(torch.unsqueeze(torch.linspace(-1.0, 1.0, height), 1), torch.ones([1, width])).to(
            source.device)

        x_t_flat = x_t.reshape([1, 1, -1])
        y_t_flat = y_t.reshape([1, 1, -1])

        num_batch = source.size()[0]
        px = torch.unsqueeze(source[:, :, 0], 2).to(source.device)  # [bn, pn, 1]
        py = torch.unsqueeze(source[:, :, 1], 2).to(source.device)  # [bn, pn, 1]

        d2 = torch.square(x_t_flat - px) + torch.square(y_t_flat - py)
        r = d2 * torch.log(d2 + 1e-6)  # [bn, pn, h*w]
        x_t_flat_g = x_t_flat.expand(num_batch, -1, -1)  # [bn, 1, h*w]
        y_t_flat_g = y_t_flat.expand(num_batch, -1, -1)  # [bn, 1, h*w]
        ones = torch.ones_like(x_t_flat_g).to(source.device)  # [bn, 1, h*w]

        grid = torch.cat((ones, x_t_flat_g, y_t_flat_g, r), 1)  # [bn, 3+pn, h*w]

        return grid

    def _transform(T, source, out_size):
        num_batch, _, _ = source.shape

        out_height, out_width = out_size[0], out_size[1]
        grid = _meshgrid(out_height, out_width, source)  # [bn, 3+pn, h*w]

        # transform A x (1, x_t, y_t, r1, r2, ..., rn) -> (x_s, y_s)
        # [bn, 2, pn+3] x [bn, pn+3, h*w] -> [bn, 2, h*w]
        T_g = torch.matmul(T, grid)
        x_s = T_g[:, 0, :]
        y_s = T_g[:, 1, :]
        x_s_flat = x_s.reshape([-1])
        y_s_flat = y_s.reshape([-1])

        # input_transformed = _interpolate(input_dim, x_s_flat, y_s_flat, out_size)
        # output = input_transformed.reshape([num_batch, out_height, out_width, num_channels])
        # output = output.permute(0, 3, 1, 2)

        flow_x = x_s_flat.reshape([num_batch, -1])
        flow_y = y_s_flat.reshape([num_batch, -1])
        tps_flow = torch.stack([flow_x, flow_y], 1).reshape([num_batch, 2, out_height, out_width])

        return tps_flow

    def _solve_system(source, target):
        num_batch = source.size()[0]
        num_point = source.size()[1]

        np.set_printoptions(precision=8)

        ones = torch.ones(num_batch, num_point, 1).float().to(source.device)

        p = torch.cat([ones, source], 2)  # [bn, pn, 3]

        p_1 = p.reshape([num_batch, -1, 1, 3])  # [bn, pn, 1, 3]
        p_2 = p.reshape([num_batch, 1, -1, 3])  # [bn, 1, pn, 3]
        d2 = torch.sum(torch.square(p_1 - p_2), 3)  # p1 - p2: [bn, pn, pn, 3]   final output: [bn, pn, pn]

        r = d2 * torch.log(d2 + 1e-6)  # [bn, pn, pn]

        zeros = torch.zeros(num_batch, 3, 3).float().to(source.device)

        W_0 = torch.cat((p, r), 2)  # [bn, pn, 3+pn]
        W_1 = torch.cat((zeros, p.permute(0, 2, 1)), 2)  # [bn, 3, pn+3]
        W = torch.cat((W_0, W_1), 1)  # [bn, pn+3, pn+3]

        W_inv = torch.inverse(W.type(torch.float64))

        zeros2 = torch.zeros(num_batch, 3, 2).to(source.device)

        tp = torch.cat((target, zeros2), 1)  # [bn, pn+3, 2]

        T = torch.matmul(W_inv, tp.type(torch.float64))  # [bn, pn+3, 2]
        T = T.permute(0, 2, 1)  # [bn, 2, pn+3]

        return T.type(torch.float32)

    norm_target_mesh = get_norm_mesh(target, output_size[0], output_size[1])
    norm_source_mesh = get_norm_mesh(source, output_size[0], output_size[1])
    T = _solve_system(norm_target_mesh, norm_source_mesh)   # backwarp warping, so swap source and target here!!!
    tps_flow = _transform(T, norm_target_mesh, output_size)
    if solve_inv:
        T_inv = _solve_system(norm_source_mesh, norm_target_mesh)
    else:
        T_inv = None

    return tps_flow, T, T_inv, source


root = '/data/wzx/dataset/Doc3d'

dataset_list = make_doc3d_dataset_list_new(root)
B = 50
for idx in range(1,22):
    if not os.path.isdir('{}/target_img/{}'.format(root, idx)):
        os.mkdir('{}/target_img/{}'.format(root, idx))

for i in range(0, len(dataset_list), B):
    img_list = []
    bm_list = []
    norm_bm_list = []
    img_path_list = []
    for j in range(B):
        if (i+j) < len(dataset_list):
            inputs_paths, flow_path, abd_path = dataset_list[i+j]
            # img = np.expand_dims(cv2.resize(cv2.imread(img_path, 1)[:, :, ::-1].astype(np.uint8), (512, 512)), axis=0)
            img = cv2.resize(cv2.imread(inputs_paths, 1)[:, :, ::-1].astype(np.uint8), (512, 512))
            bm = load_flo_TPSGen(flow_path)  # [h,w,(column,row)]
            img_list.append(img)
            bm_list.append(bm)
            img_path_list.append(inputs_paths)
            norm_bm = torch.from_numpy(bm.transpose(2, 0, 1)).unsqueeze(
                0).float().clone()  # [1, 2, 512, 512]
            shape = norm_bm.shape[2:]  # Height and width of flow field (512, 512)

            # Normalize flow to [-1, 1] (required for bilinear registration model)
            for k in range(len(shape)):
                norm_bm[:, k, ...] = 2 * (norm_bm[:, k, ...] / (shape[k] - 1) - 0.5)
            norm_bm_list.append(norm_bm.squeeze())
            # print(i+j)

    img_tensor = torch.from_numpy(np.array(img_list)).to(dtype=torch.float32).to(device)
    norm_bm_tensor = torch.from_numpy(np.array(norm_bm_list)).to(dtype=torch.float32).to(device)
    warped_img = F.grid_sample(img_tensor.permute(0,3,1,2), norm_bm_tensor.permute(0, 2, 3, 1), mode='bilinear', align_corners=True)
    # cv2.imwrite('warped_img.jpg', warped_img[10].permute(1,2,0).cpu().numpy())

    for j in range(B):
        if i +j < len(dataset_list):
            dir_idx = (img_path_list[j].split('/')[-2])
            img_name = (img_path_list[j].split('/')[-1]).split('.')[0]
            cv2.imwrite('{}/target_img/{}/{}.png'.format(root, dir_idx, img_name), warped_img[j].permute(1, 2, 0).cpu().numpy().take([2,1,0], axis=-1))
    print('process {} images.'.format(i+B))
print('done')