import os
import json
import h5py
import numpy as np

import config.settings as settings
def load_grid3d_mat(grid3d_path):
    grid3d = h5py.File(grid3d_path)
    grid3d = grid3d['grid3d'][:].transpose((2, 1, 0))
    xmx, xmn, ymx, ymn, zmx, zmn = settings.train.grid3d_normalization
    grid3d[:, :, 0] = (grid3d[:, :, 0] - xmn) / (xmx - xmn)
    grid3d[:, :, 1] = (grid3d[:, :, 1] - ymn) / (ymx - ymn)
    grid3d[:, :, 2] = (grid3d[:, :, 2] - zmn) / (zmx - zmn)
    grid3d[:, :, 2] = 1 - grid3d[:, :, 2]
    # grid3d = 2 * grid3d - 1
    return grid3d   # [depth, column, row], [0,1]

if __name__ == "__main__":
    dir = 'E:/Dataset/UVDoc/UVDoc_final'
    for sample in os.listdir('{}/metadata_sample'.format(dir)):
        with open('{}/metadata_sample/{}'.format(dir, sample), 'r', encoding='utf-8') as file:
            data = json.load(file)
            grid3d_path = '{}/grid3d/{}.mat'.format(dir, data['geom_name'])
            grid3d = load_grid3d_mat(grid3d_path)
            print(np.mean(grid3d[:, :, 0]))
    print('done')