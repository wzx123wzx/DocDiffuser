import numpy as np
import torch
import torch.nn.functional as F
def mse_loss(img1, img2, mask=None):
    if mask is not None:
        return torch.sum((img1 - img2) ** 2) / torch.sum(mask)
    else:
        return torch.sum((img1 - img2) ** 2) / torch.sum(torch.ones_like(img1))

def inter_grid_loss(mesh):

    ##############################
    # compute horizontal edges
    w_edges = mesh[:,:,0:grid_w,:] - mesh[:,:,1:grid_w+1,:]
    # compute angles of two successive horizontal edges
    cos_w = torch.sum(w_edges[:,:,0:grid_w-1,:] * w_edges[:,:,1:grid_w,:],3) / (torch.sqrt(torch.sum(w_edges[:,:,0:grid_w-1,:]*w_edges[:,:,0:grid_w-1,:],3))*torch.sqrt(torch.sum(w_edges[:,:,1:grid_w,:]*w_edges[:,:,1:grid_w,:],3)))
    # horizontal angle-preserving error for two successive horizontal edges
    delta_w_angle = 1 - cos_w
    # horizontal angle-preserving error for two successive horizontal grids
    delta_w_angle = delta_w_angle[:,0:grid_h,:] + delta_w_angle[:,1:grid_h+1,:]
    ##############################

    ##############################
    # compute vertical edges
    h_edges = mesh[:,0:grid_h,:,:] - mesh[:,1:grid_h+1,:,:]
    # compute angles of two successive vertical edges
    cos_h = torch.sum(h_edges[:,0:grid_h-1,:,:] * h_edges[:,1:grid_h,:,:],3) / (torch.sqrt(torch.sum(h_edges[:,0:grid_h-1,:,:]*h_edges[:,0:grid_h-1,:,:],3))*torch.sqrt(torch.sum(h_edges[:,1:grid_h,:,:]*h_edges[:,1:grid_h,:,:],3)))
    # vertical angle-preserving error for two successive vertical edges
    delta_h_angle = 1 - cos_h
    # vertical angle-preserving error for two successive vertical grids
    delta_h_angle = delta_h_angle[:,:,0:grid_w] + delta_h_angle[:,:,1:grid_w+1]
    ##############################

    # # on overlapping regions
    # depth_diff_w = (1-torch.abs(overlap[:,:,0:grid_w-1] - overlap[:,:,1:grid_w])) * overlap[:,:,0:grid_w-1]
    # error_w = depth_diff_w * delta_w_angle
    # # on overlapping regions
    # depth_diff_h = (1-torch.abs(overlap[:,0:grid_h-1,:] - overlap[:,1:grid_h,:])) * overlap[:,0:grid_h-1,:]
    # error_h = depth_diff_h * delta_h_angle

    error_w = delta_w_angle
    error_h = delta_h_angle

    return torch.mean(error_w) + torch.mean(error_h)



# intra-grid constraint
def intra_grid_loss(mesh):

    max_w = 512/grid_w * 2
    max_h = 512/grid_h * 2

    delta_x = mesh[:,:,1:grid_w+1,0] - mesh[:,:,0:grid_w,0]
    delta_y = mesh[:,1:grid_h+1,:,1] - mesh[:,0:grid_h,:,1]

    loss_x = F.relu(delta_x - max_w)
    loss_y = F.relu(delta_y - max_h)
    loss = torch.mean(loss_x) + torch.mean(loss_y)


    return loss

# intra-grid constraint
def axis_alignment_loss(mesh, gt_mesh):

    # extract mesh based on gt_mesh
    max_w = 512/grid_w * 2
    max_h = 512/grid_h * 2

    delta_x = mesh[:,:,1:grid_w+1,0] - mesh[:,:,0:grid_w,0]
    delta_y = mesh[:,1:grid_h+1,:,1] - mesh[:,0:grid_h,:,1]

    loss_x = F.relu(delta_x - max_w)
    loss_y = F.relu(delta_y - max_h)
    loss = torch.mean(loss_x) + torch.mean(loss_y)


    return loss

def mask_loss(tps_flow, doc_mask):

    update_feat = F.grid_sample(doc_mask, tps_flow.permute(0, 2, 3, 1),
                                            mode=settings.model.interpolation_mode, align_corners=True)


    return loss