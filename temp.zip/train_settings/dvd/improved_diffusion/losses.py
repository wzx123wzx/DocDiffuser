"""
Helpers for various likelihood-based losses. These are ported from the original
Ho et al. diffusion models codebase:
https://github.com/hojonathanho/diffusion/blob/1e0dceb3b3495bbe19116a5e1b3596cd0706c543/diffusion_tf/utils.py
"""
import cv2
import numpy as np
import torch
import torch.nn.functional as F
import config.settings as settings

grid_h = settings.model.tps_resolution
grid_w = settings.model.tps_resolution


def normal_kl(mean1, logvar1, mean2, logvar2):
    """
    Compute the KL divergence between two gaussians.

    Shapes are automatically broadcasted, so batches can be compared to
    scalars, among other use cases.
    """
    tensor = None
    for obj in (mean1, logvar1, mean2, logvar2):
        if isinstance(obj, torch.Tensor):
            tensor = obj
            break
    assert tensor is not None, "at least one argument must be a Tensor"

    # Force variances to be Tensors. Broadcasting helps convert scalars to
    # Tensors, but it does not work for torch.exp().
    logvar1, logvar2 = [
        x if isinstance(x, torch.Tensor) else torch.tensor(x).to(tensor)
        for x in (logvar1, logvar2)
    ]

    return 0.5 * (
            -1.0
            + logvar2
            - logvar1
            + torch.exp(logvar1 - logvar2)
            + ((mean1 - mean2) ** 2) * torch.exp(-logvar2)
    )


def approx_standard_normal_cdf(x):
    """
    A fast approximation of the cumulative distribution function of the
    standard normal.
    """
    return 0.5 * (1.0 + torch.tanh(np.sqrt(2.0 / np.pi) * (x + 0.044715 * torch.pow(x, 3))))


def discretized_gaussian_log_likelihood(x, *, means, log_scales):
    """
    Compute the log-likelihood of a Gaussian distribution discretizing to a
    given image.

    :param x: the target images. It is assumed that this was uint8 values,
              rescaled to the range [-1, 1].
    :param means: the Gaussian mean Tensor.
    :param log_scales: the Gaussian log stddev Tensor.
    :return: a tensor like x of log probabilities (in nats).
    """
    assert x.shape == means.shape == log_scales.shape
    centered_x = x - means
    inv_stdv = torch.exp(-log_scales)
    plus_in = inv_stdv * (centered_x + 1.0 / 255.0)
    cdf_plus = approx_standard_normal_cdf(plus_in)
    min_in = inv_stdv * (centered_x - 1.0 / 255.0)
    cdf_min = approx_standard_normal_cdf(min_in)
    log_cdf_plus = torch.log(cdf_plus.clamp(min=1e-12))
    log_one_minus_cdf_min = torch.log((1.0 - cdf_min).clamp(min=1e-12))
    cdf_delta = cdf_plus - cdf_min
    log_probs = torch.where(
        x < -0.999,
        log_cdf_plus,
        torch.where(x > 0.999, log_one_minus_cdf_min, torch.log(cdf_delta.clamp(min=1e-12))),
    )
    assert log_probs.shape == x.shape
    return log_probs


def mse_loss(img1, img2, mask=None):
    if mask is not None:
        return torch.sum((img1 - img2) ** 2) / torch.sum(mask)
    else:
        return torch.sum((img1 - img2) ** 2) / torch.sum(torch.ones_like(img1))


def inter_grid_loss(mesh):
    # mesh: [b,16,16,2]
    ##############################
    # compute horizontal edges
    w_edges = mesh[:, :, 0:grid_w-1, :] - mesh[:, :, 1:grid_w, :]
    # compute angles of two successive horizontal edges
    cos_w = torch.sum(w_edges[:, :, 0:grid_w - 2, :] * w_edges[:, :, 1:grid_w-1, :], 3) / (
            torch.sqrt(torch.sum(w_edges[:, :, 0:grid_w - 2, :] * w_edges[:, :, 0:grid_w - 2, :], 3)) * torch.sqrt(
        torch.sum(w_edges[:, :, 1:grid_w-1, :] * w_edges[:, :, 1:grid_w-1, :], 3)))
    # horizontal angle-preserving error for two successive horizontal edges
    delta_w_angle = 1 - cos_w
    # horizontal angle-preserving error for two successive horizontal grids
    delta_w_angle = delta_w_angle[:, 0:grid_h-1, :] + delta_w_angle[:, 1:grid_h, :]
    ##############################

    ##############################
    # compute vertical edges
    h_edges = mesh[:, 0:grid_h-1, :, :] - mesh[:, 1:grid_h, :, :]
    # compute angles of two successive vertical edges
    cos_h = torch.sum(h_edges[:, 0:grid_h - 2, :, :] * h_edges[:, 1:grid_h-1, :, :], 3) / (
            torch.sqrt(torch.sum(h_edges[:, 0:grid_h - 2, :, :] * h_edges[:, 0:grid_h - 2, :, :], 3)) * torch.sqrt(
        torch.sum(h_edges[:, 1:grid_h-1, :, :] * h_edges[:, 1:grid_h-1, :, :], 3)))
    # vertical angle-preserving error for two successive vertical edges
    delta_h_angle = 1 - cos_h
    # vertical angle-preserving error for two successive vertical grids
    delta_h_angle = delta_h_angle[:, :, 0:grid_w-1] + delta_h_angle[:, :, 1:grid_w]
    ##############################

    # # on overlapping regions
    # depth_diff_w = (1-torch.abs(overlap[:,:,0:grid_w-1] - overlap[:,:,1:grid_w])) * overlap[:,:,0:grid_w-1]
    # error_w = depth_diff_w * delta_w_angle
    # # on overlapping regions
    # depth_diff_h = (1-torch.abs(overlap[:,0:grid_h-1,:] - overlap[:,1:grid_h,:])) * overlap[:,0:grid_h-1,:]
    # error_h = depth_diff_h * delta_h_angle

    error_w = delta_w_angle
    error_h = delta_h_angle

    return torch.mean(error_w) + torch.mean(error_h)


# intra-grid constraint
def intra_grid_loss(mesh):
    max_w = 512 / grid_w * 2
    max_h = 512 / grid_h * 2

    delta_x = mesh[:, :, 1:grid_w + 1, 0] - mesh[:, :, 0:grid_w, 0]
    delta_y = mesh[:, 1:grid_h + 1, :, 1] - mesh[:, 0:grid_h, :, 1]

    loss_x = F.relu(delta_x - max_w)
    loss_y = F.relu(delta_y - max_h)
    loss = torch.mean(loss_x) + torch.mean(loss_y)

    return loss

# axis alignment loss
def axis_alignment_loss(mesh, gt_mesh, T_inv, size):
    # mesh: mesh, [b, grid_h, grid_w, 2]
    # gt_mesh: mesh, [b, grid_h, grid_w, 2]
    # T_inv: [b, 2, num_mesh_grids+3], tps transformation parameters
    def get_norm_mesh(mesh, height, width):
        B, _, _, _ = mesh.shape
        mesh_w = mesh[..., 0] * 2. / float(width) - 1.
        mesh_h = mesh[..., 1] * 2. / float(height) - 1.
        norm_mesh = torch.stack([mesh_w, mesh_h], 3)  # bs*(grid_h+1)*(grid_w+1)*2

        return norm_mesh.reshape([B, -1, 2])  # bs*-1*2

    def _meshgrid(mesh, gt_mesh):
        # new_source: [b, pn_new, 2]
        # source: [b, pn, 2]
        x_t = mesh[:, :, 0]  # [b, pn_new]
        y_t = mesh[:, :, 1]  # [b, pn_new]

        x_t_flat = x_t.unsqueeze(1)  # [b,1,pn_new]
        y_t_flat = y_t.unsqueeze(1)  # [b,1,pn_new]

        px = torch.unsqueeze(gt_mesh[:, :, 0], 2).to(gt_mesh.device)  # [bn, pn, 1]
        py = torch.unsqueeze(gt_mesh[:, :, 1], 2).to(gt_mesh.device)  # [bn, pn, 1]

        d2 = torch.square(x_t_flat - px) + torch.square(y_t_flat - py)  # [b, pn, pn_new]
        r = d2 * torch.log(d2 + 1e-6)  # [bn, pn, pn_new]
        ones = torch.ones_like(x_t_flat).to(gt_mesh.device)  # [bn, 1, pn_new]

        grid = torch.cat((ones, x_t_flat, y_t_flat, r), 1)  # [bn, 3+pn, pn_new]

        return grid
    b, grid_h, grid_w, _ = mesh.shape
    norm_mesh = get_norm_mesh(mesh, size[0], size[1])
    norm_gt_mesh = get_norm_mesh(gt_mesh, size[0], size[1])
    meshgrid = _meshgrid(norm_gt_mesh, norm_mesh)
    T_meshgrid = torch.matmul(T_inv, meshgrid)
    T_meshgrid = T_meshgrid.reshape(b, 2, grid_h, grid_w)   # [b,2,grid_h,grid_w]
    T_meshgrid_x = T_meshgrid[:, 0, :, :]   # [b, grid_h, grid_w]
    T_meshgrid_y = T_meshgrid[:, 1, :, :]   # [b, grid_h, grid_w]
    var_x = torch.var(T_meshgrid_x, dim=1)  # column, [b, grid_w]
    var_y = torch.var(T_meshgrid_y, dim=2)  # row, [b, grid_w]
    return torch.mean(var_x) + torch.mean(var_y)


def mask_loss(tps_flow, doc_mask):
    warped_doc_mask = F.grid_sample(doc_mask, tps_flow.permute(0, 2, 3, 1), mode='bilinear', align_corners=True)    # [b,1,512,512], [0,1]
    loss = torch.mean(torch.abs(warped_doc_mask - 1))
    # cv2.imwrite('doc_mask.jpg', 255*doc_mask[0].squeeze().cpu().detach().numpy())
    # cv2.imwrite('warped_doc_mask.jpg', 255*warped_doc_mask[0].squeeze().cpu().detach().numpy())
    return loss

def depth_loss(tps_3dflow, target_depth):
    # [b, h, w, 3]
    loss = torch.var(tps_3dflow[:, :, :, 2], dim=(1,2))
    # b, h, w, _ = tps_3dflow.shape
    # loss = torch.var((tps_3dflow[:, :, :, 2]-(2*target_depth-1).unsqueeze(-1).unsqueeze(-1).repeat(1,h,w)), dim=(1, 2))
    return torch.mean(loss)
