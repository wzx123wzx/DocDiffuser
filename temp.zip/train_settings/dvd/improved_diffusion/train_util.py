# Python standard library imports
import copy
import functools
import os
from torch.utils.tensorboard import SummaryWriter
import datetime
import blobfile as bf
import numpy as np
import torch
import torch.nn.functional as F
# Remove DistributedDataParallel since single-GPU training doesn't need model parallelism
# from torch.nn.parallel.distributed import DistributedDataParallel as DDP
from torch.optim import AdamW

from train_settings.dvd.feature_backbones.VGG_features import VGGPyramid

from ..eval_utils import extract_raw_features_single, extract_raw_features_single2
from ..evaluation import prepare_train_data
# Remove distributed utilities (dist_util) as single-GPU training doesn't require inter-process communication
from . import logger
from .fp16_util import (make_master_params, master_params_to_model_params,
                        model_grads_to_master_grads, unflatten_master_params,
                        zero_grad)
from utils_transform.tps_utils import draw_mesh_on_warp
from .nn import update_ema
from .resample import UniformSampler
from torchvision.utils import save_image as tv_save_image
import config.settings as settings
from PIL import Image
import config.settings as settings

INITIAL_LOG_LOSS_SCALE = 20.0


def coords_grid_tensor(perturbed_img_shape):
    im_x, im_y = np.mgrid[0:287:complex(perturbed_img_shape[0]),
                 0:287:complex(perturbed_img_shape[1])]
    coords = np.stack((im_y, im_x), axis=2)  # Stack y and x coordinates (column-major order)
    coords = torch.from_numpy(coords).float().permute(2, 0, 1)  # (2, H, W)
    return coords.unsqueeze(0)  # Add batch dimension [1, 2, H, W]


class TrainLoop:
    def __init__(
            self,
            *,
            model,
            pretrained_dewarp_model,
            pretrained_line_seg_model,
            diffusion,
            settings,
            batch_preprocessing,
            data,
            schedule_sampler=None,
            batch_size=settings.train.batch_size,
            microbatch=settings.train.microbatch,
            lr=settings.train.lr,
            ema_rate=settings.train.ema_rate,
            log_interval=settings.log.log_interval,
            save_interval=settings.log.save_interval,
            tb_interval=settings.log.tb_interval,
            resume_checkpoint=settings.log.resume_checkpoint,
            use_fp16=settings.train.use_fp16,
            fp16_scale_growth=settings.train.fp16_scale_growth,
            weight_decay=settings.train.weight_decay,
            lr_anneal_steps=settings.train.lr_anneal_steps,
            resume_step=settings.log.resume_step,
            use_gt_mask=settings.train.use_gt_mask,
            use_init_flow=settings.train.use_init_flow,
            train_mode=settings.train.train_mode,
            use_line_mask=settings.train.use_line_mask
    ):
        self.model = model
        self.pretrained_dewarp_model = pretrained_dewarp_model
        self.pretrained_line_seg_model = pretrained_line_seg_model
        self.diffusion = diffusion
        self.settings = settings
        self.data = data
        self.batch_size = batch_size
        self.microbatch = microbatch if microbatch > 0 else batch_size
        self.lr = lr
        self.ema_rate = (
            [ema_rate]
            if isinstance(ema_rate, float)
            else [float(x) for x in ema_rate.split(",")]
        )
        self.log_interval = log_interval
        self.save_interval = save_interval
        self.tb_interval = tb_interval
        self.resume_checkpoint = resume_checkpoint
        self.use_fp16 = use_fp16
        self.fp16_scale_growth = fp16_scale_growth
        self.schedule_sampler = schedule_sampler or UniformSampler(diffusion)
        self.weight_decay = weight_decay
        self.lr_anneal_steps = lr_anneal_steps

        self.step = 0
        self.resume_step = resume_step
        self.use_gt_mask = use_gt_mask
        self.use_init_flow = use_init_flow
        self.use_line_mask = use_line_mask
        self.train_mode = train_mode
        # Single-GPU training: global batch size equals local batch size
        self.global_batch = self.batch_size
        self.model_params = list(self.model.parameters())
        self.master_params = self.model_params
        self.lg_loss_scale = INITIAL_LOG_LOSS_SCALE
        self.sync_cuda = torch.cuda.is_available()

        self._load_and_sync_parameters()
        if self.use_fp16:
            self._setup_fp16()

        self.opt = AdamW(self.master_params, lr=self.lr, weight_decay=self.weight_decay)
        if self.resume_step:
            print(f"Resuming from checkpoint with optimizer at step {self.resume_step}")
            self._load_optimizer_state()
            self.ema_params = [
                self._load_ema_parameters(rate) for rate in self.ema_rate
            ]
        else:
            print("Initializing training from scratch (no resume)")
            self.ema_params = [
                copy.deepcopy(self.master_params) for _ in range(len(self.ema_rate))
            ]

        self.use_ddp = False
        self.ddp_model = self.model

        self.batch_processing = batch_preprocessing
        list_time = list(str(datetime.datetime.now()))[:16]
        list_time[10] = '-'
        str_time = ''.join(list_time)
        # self.writer = SummaryWriter(log_dir='{}/{}'.format(bf.join(get_blob_logdir()), str_time))
        self.writer = SummaryWriter(log_dir='{}'.format(bf.join(get_blob_logdir())))

    def _load_and_sync_parameters(self):
        resume_checkpoint = find_resume_checkpoint() or self.resume_checkpoint

        if resume_checkpoint:
            # Single-GPU: load directly without distributed sync
            state_dict = self._load_state_dict(resume_checkpoint)
            self.resume_step = parse_resume_step_from_filename(resume_checkpoint)
            self.model.load_state_dict(state_dict, strict=False)
            self.model.to(settings.train.device)  # Move to local device

        # Remove distributed parameter sync (no multiple processes)

    def _load_ema_parameters(self, rate):
        ema_params = copy.deepcopy(self.master_params)

        main_checkpoint = find_resume_checkpoint() or self.resume_checkpoint
        ema_checkpoint = find_ema_checkpoint(main_checkpoint, self.resume_step, rate)
        if ema_checkpoint:
            logger.log(f"Loading EMA parameters from {ema_checkpoint}")
            state_dict = self._load_state_dict(ema_checkpoint)
            ema_params = self._state_dict_to_master_params(state_dict)

        return ema_params

    def _load_optimizer_state(self):
        main_checkpoint = find_resume_checkpoint() or self.resume_checkpoint
        opt_checkpoint = bf.join(
            bf.dirname(main_checkpoint), f"opt{self.resume_step:06}.pt"
        )
        if bf.exists(opt_checkpoint):
            logger.log(f"Loading optimizer state from {opt_checkpoint}")
            state_dict = torch.load(opt_checkpoint, map_location=settings.train.device)
            self.opt.load_state_dict(state_dict)

    def _setup_fp16(self):
        self.master_params = make_master_params(self.model_params)
        self.model.convert_to_fp16()

    def run_loop_dewarping(self):
        self.embedding_cond_size = settings.model.embedding_cond_size
        self.tps_resolusion = settings.model.tps_resolution
        self.radius = settings.model.radius

        while True:
            if self.lr_anneal_steps or self.step + self.resume_step < self.lr_anneal_steps:
                break

            indices = list(range(0, len(self.data)))

            self.pyramid = VGGPyramid(train=False).to(settings.train.device)
            SIZE = None

            batch_preprocessing = None
            for i, data in zip(indices, self.data):
                # data['doc_image']: [b,3,512,512], [0,1]
                # data['doc_mask']: [b,1,512,512], [0,1]
                # data['doc_bm']: [b,2,512,512], w/o normalization
                # data['doc_target_image']: [b,3,512,512], [0,1]
                # data['doc_norm_bm']: [b,2,512,512], w normalization

                # move data to cuda
                # data['doc_image'] = data['doc_image'].to(settings.train.device)
                # data['doc_mask'] = data['doc_mask'].to(settings.train.device)
                # data['doc_bm'] = data['doc_bm'].to(settings.train.device)
                # data['doc_target_image'] = data['doc_target_image'].to(settings.train.device)
                # data['doc_norm_bm'] = data['doc_norm_bm'].to(settings.train.device)

                source_288 = F.interpolate(data['doc_image'], size=288, mode='bilinear', align_corners=True).to(
                    settings.train.device)

                if self.settings.train.time_variant == True:
                    update_feat = torch.zeros(
                        (data['doc_image'].shape[0], 256, self.embedding_cond_size, self.embedding_cond_size),
                        dtype=torch.float32).to(settings.train.device)
                    if settings.model.use_3dtps:
                        update_tps_motion = torch.zeros(
                            (data['doc_image'].shape[0], 3, self.tps_resolusion, self.tps_resolusion),
                            dtype=torch.float32).to(settings.train.device)
                    else:
                        update_tps_motion = torch.zeros(
                        (data['doc_image'].shape[0], 2, self.tps_resolusion, self.tps_resolusion),
                        dtype=torch.float32).to(settings.train.device)
                else:
                    update_feat = None
                    update_tps_motion = None

                if self.use_init_flow:
                    with torch.no_grad():
                        ref_bm, mask_x = self.pretrained_dewarp_model(source_288)
                    base = coords_grid_tensor((288, 288)).to(ref_bm.device)
                    ref_flow = ref_bm - base
                    ref_flow = ref_flow / 287.0
                    update_flow = F.interpolate(ref_flow, size=(self.embedding_cond_size, self.embedding_cond_size),
                                                mode='bilinear',
                                                align_corners=True)
                else:
                    update_flow = torch.zeros(
                        (data['doc_image'].shape[0], 2, self.embedding_cond_size, self.embedding_cond_size),
                        dtype=torch.float32).to(settings.train.device)

                (
                    data,
                    H_ori,
                    W_ori,
                    source,
                    target,
                    source_256,
                    bm,
                    norm_bm,
                    grid2d,
                    grid3d,
                    mask
                ) = prepare_train_data(self.settings, batch_preprocessing, SIZE, data)

                with torch.no_grad():
                    if self.use_gt_mask == False:
                        mskx, d0, hx6, hx5d, hx4d, hx3d, hx2d, hx1d = self.pretrained_dewarp_model(source_288)
                        hx6 = F.interpolate(hx6, size=self.embedding_cond_size, mode='bilinear', align_corners=False)
                        hx5d = F.interpolate(hx5d, size=self.embedding_cond_size, mode='bilinear', align_corners=False)
                        hx4d = F.interpolate(hx4d, size=self.embedding_cond_size, mode='bilinear', align_corners=False)
                        hx3d = F.interpolate(hx3d, size=self.embedding_cond_size, mode='bilinear', align_corners=False)
                        hx2d = F.interpolate(hx2d, size=self.embedding_cond_size, mode='bilinear', align_corners=False)
                        hx1d = F.interpolate(hx1d, size=self.embedding_cond_size, mode='bilinear', align_corners=False)

                        # [b,384,512,512]
                        seg_map_all = torch.cat((hx6, hx5d, hx4d, hx3d, hx2d, hx1d), dim=1)
                        if self.use_line_mask:
                            # [b,64,512,512]
                            textline_map, textline_mask = self.pretrained_line_seg_model(mskx)
                            textline_map = F.interpolate(textline_map, size=self.embedding_cond_size, mode='bilinear',
                                                         align_corners=False)
                    else:
                        seg_map_all = None
                        textline_map = None

                if self.settings.train.train_VGG:
                    c20 = None
                else:
                    if self.train_mode == 'stage_1_dit_cat' or 'stage_1_dit_cross':
                        with torch.no_grad():
                            c20 = extract_raw_features_single2(self.pyramid, source, source_256,
                                                               feature_size=self.embedding_cond_size)
                    else:
                        with torch.no_grad():
                            c20 = extract_raw_features_single(self.pyramid, source, source_256,
                                                              self.embedding_cond_size)

                cond = {'source': source, 'update_flow': update_flow,
                        'src_feat': c20, 'tv': self.settings.train.time_variant, 'tmode': self.train_mode,
                        'mask': data['doc_mask'].to(source.device),
                        'update_feat': update_feat,
                        'update_tps_motion': update_tps_motion,
                        'iter': self.settings.train.iter,
                        'mode': "train", 'path': data['doc_path']}
                if self.use_gt_mask == False:
                    cond['seg_mask'] = seg_map_all
                if self.use_line_mask == True:
                    cond['line_msk'] = textline_map

                self.run_step(bm, norm_bm, grid2d, grid3d, mask, cond, self.pyramid)

                if self.step % self.log_interval == 0:
                    logger.dumpkvs()
                if self.step % self.save_interval == 0:
                    self.save()
                    if os.environ.get("DIFFUSION_TRAINING_TEST", "") and self.step > 0:
                        return
                self.step += 1

        if (self.step - 1) % self.save_interval != 0:
            self.save()

    def get_gpu_memory_usage(self, device_id=None):
        allocated_bytes = torch.cuda.memory_allocated(0)
        return allocated_bytes

    def run_step(self, bm, norm_bm, grid2d, grid3d, mask, cond, pyramid=None):
        if cond['iter'] == True:
            self.forward_backward_iteration(bm, norm_bm, grid2d, grid3d, mask, cond, pyramid)
        elif cond['tmode'] == "stage_1_dit_cat" or cond['tmode'] == "stage_1_dit_cross":
            self.forward_backward_new_dit(bm, norm_bm, mask, cond)

        if self.use_fp16:
            self.optimize_fp16()
        else:
            self.optimize_normal()
        self.log_step()

    def forward_backward_new_dit(self, batch, batch_ori, mask, cond):
        zero_grad(self.model_params)
        for i in range(0, batch.shape[0], self.microbatch):
            micro = batch[i: i + self.microbatch].to(settings.train.device)
            micro_ori = batch_ori[i: i + self.microbatch].to(settings.train.device)

            last_batch = (i + self.microbatch) >= batch.shape[0]
            t, weights = self.schedule_sampler.sample(micro.shape[0], settings.train.device)
            if weights is None:
                weights = torch.ones(micro.shape[0]).to(settings.train.device)

            compute_losses = functools.partial(
                self.diffusion.training_losses_new_dit,
                self.ddp_model,
                micro,
                micro_ori,
                mask,
                t,
                model_kwargs=cond,
            )

            # Single-GPU: no need for DDP no_sync() context
            losses = compute_losses()

            loss = (losses["loss"] * weights).mean()
            log_loss_dict(
                self.diffusion, t, {k: v * weights for k, v in losses.items()}
            )

            if self.use_fp16:
                loss_scale = 2 ** self.lg_loss_scale
                (loss * loss_scale).backward()
            else:
                loss.backward()

            torch.nn.utils.clip_grad_norm_(self.ddp_model.parameters(), max_norm=1.0)

    def forward_backward_iteration(self, bm, norm_bm, grid2d, grid3d, mask, cond, pyramid):
        # bm: [b,2,512,512]
        # norm_bm: [b,2,512,512]
        # mask: [1,512,512]
        # cond: dict
        # cond['source']: [b,3,512,512], [0,1]
        # cond['init_flow']: [b,2,512,512]
        # cond['update_flow']: [b,2,512,512]
        # cond['mask']: [b,1,512,512], [0,1]
        # cond['init_flow']: [b,2,512,512]
        # cond['update_flow']: [b,2,512,512]
        # cond['update_tps_motion']: [b,2,16,16]
        # cond['seg_mask']: [b,384,512,511]
        # cond['line_mask']: [b,64,512,512]
        zero_grad(self.model_params)
        for i in range(0, cond['source'].shape[0], self.microbatch):
            if bm is not None:
                micro = bm[i: i + self.microbatch].to(settings.train.device)
                micro_norm = norm_bm[i: i + self.microbatch].to(settings.train.device)
            else:
                micro = None
                micro_norm = None

            if grid2d is not None:
                micro_grid2d = grid2d[i: i + self.microbatch].to(settings.train.device)
            else:
                micro_grid2d = None

            if grid3d is not None:
                micro_grid3d = grid3d[i: i + self.microbatch].to(settings.train.device)
            else:
                micro_grid3d = None

            # sample time step (0~T-1) for each batch
            t, weights = self.schedule_sampler.sample(micro.shape[0], settings.train.device)

            compute_losses = functools.partial(
                self.diffusion.training_losses_time_variant,
                self.ddp_model,
                micro,
                micro_norm,
                micro_grid2d,
                micro_grid3d,
                mask,
                t,
                model_kwargs=cond,
                pyramid=pyramid
            )

            losses, tb_terms = compute_losses()

            loss = (losses["loss"] * weights).mean()
            log_loss_dict(
                self.diffusion, t, {k: v * weights for k, v in losses.items()}
            )
            if self.use_fp16:
                loss_scale = 2 ** self.lg_loss_scale
                (loss * loss_scale).backward()
            else:
                loss.backward()

            torch.nn.utils.clip_grad_norm_(self.ddp_model.parameters(), max_norm=1.0)

            if self.step % self.tb_interval == 0:
                if self.step % (10 * self.tb_interval) == 0:
                    self.write_tensorboard(losses, imgs=tb_terms)
                else:
                    self.write_tensorboard(losses, imgs=None)

    def forward_backward_new(self, batch, batch_ori, batch_ori_inter, mask, cond):
        zero_grad(self.model_params)
        for i in range(0, batch.shape[0], self.microbatch):
            micro = batch[i: i + self.microbatch].to(settings.train.device)
            micro_ori = batch_ori[i: i + self.microbatch].to(settings.train.device)
            micro_ori_inter = batch_ori_inter[i: i + self.microbatch].to(settings.train.device)

            last_batch = (i + self.microbatch) >= batch.shape[0]
            t, weights = self.schedule_sampler.sample(micro.shape[0], settings.train.device)
            if weights is None:
                weights = torch.ones(24).to(settings.train.device)

            compute_losses = functools.partial(
                self.diffusion.training_losses_new,
                self.ddp_model,
                micro,
                micro_ori,
                micro_ori_inter,
                mask,
                t,
                model_kwargs=cond,
            )

            losses = compute_losses()

            loss = (losses["loss"] * weights).mean()
            log_loss_dict(
                self.diffusion, t, {k: v * weights for k, v in losses.items()}
            )

            if self.use_fp16:
                loss_scale = 2 ** self.lg_loss_scale
                (loss * loss_scale).backward()
            else:
                loss.backward()

            torch.nn.utils.clip_grad_norm_(self.ddp_model.parameters(), max_norm=1.0)

    def forward_backward(self, batch, batch_ori, mask, cond):
        zero_grad(self.model_params)
        for i in range(0, batch.shape[0], self.microbatch):
            micro = batch[i: i + self.microbatch].to(settings.train.device)
            micro_ori = batch_ori[i: i + self.microbatch].to(settings.train.device)

            last_batch = (i + self.microbatch) >= batch.shape[0]
            t, weights = self.schedule_sampler.sample(micro.shape[0], settings.train.device)
            if weights is None:
                weights = torch.ones(24).to(settings.train.device)

            compute_losses = functools.partial(
                self.diffusion.training_losses,
                self.ddp_model,
                micro,
                micro_ori,
                mask,
                t,
                model_kwargs=cond,
            )

            losses = compute_losses()

            loss = (losses["loss"] * weights).mean()
            log_loss_dict(
                self.diffusion, t, {k: v * weights for k, v in losses.items()}
            )

            if self.use_fp16:
                loss_scale = 2 ** self.lg_loss_scale
                (loss * loss_scale).backward()
            else:
                loss.backward()

            torch.nn.utils.clip_grad_norm_(self.ddp_model.parameters(), max_norm=1.0)

    def optimize_fp16(self):
        if any(not torch.isfinite(p.grad).all() for p in self.model_params):
            self.lg_loss_scale -= 1
            logger.log(f"Found NaN, decreased lg_loss_scale to {self.lg_loss_scale}")
            return

        model_grads_to_master_grads(self.model_params, self.master_params)
        self.master_params[0].grad.mul_(1.0 / (2 ** self.lg_loss_scale))
        self._log_grad_norm()
        self._anneal_lr()
        self.opt.step()
        for rate, params in zip(self.ema_rate, self.ema_params):
            update_ema(params, self.master_params, rate=rate)
        master_params_to_model_params(self.model_params, self.master_params)
        self.lg_loss_scale += self.fp16_scale_growth

    def optimize_normal(self):
        self._log_grad_norm()
        self._anneal_lr()
        self.opt.step()
        for rate, params in zip(self.ema_rate, self.ema_params):
            update_ema(params, self.master_params, rate=rate)

    def _log_grad_norm(self):
        sqsum = 0.0
        for p in self.master_params:
            if p.grad is None:
                continue
            sqsum += (p.grad ** 2).sum().item()
        logger.logkv_mean("grad_norm", np.sqrt(sqsum))

    def _anneal_lr(self):
        if not self.lr_anneal_steps:
            return
        frac_done = (self.step + self.resume_step) / self.lr_anneal_steps
        lr = self.lr * (1 - frac_done)
        for param_group in self.opt.param_groups:
            param_group["lr"] = lr

    def log_step(self):
        logger.logkv("step", self.step + self.resume_step)
        logger.logkv("samples", (self.step + self.resume_step + 1) * self.global_batch)
        if self.use_fp16:
            logger.logkv("lg_loss_scale", self.lg_loss_scale)

    def write_tensorboard(self, losses, imgs):
        if losses is not None:
            self.writer.add_scalar('total_loss', losses['loss'].item(), self.step + self.resume_step)
            self.writer.add_scalar('mse_loss', losses['mse'].item(), self.step + self.resume_step)
            if settings.train.use_mask_loss:
                self.writer.add_scalar('mask_loss', losses['mask'].item(), self.step + self.resume_step)
            if settings.train.use_inter_loss:
                self.writer.add_scalar('inter_loss', losses['inter'].item(), self.step + self.resume_step)
            if settings.train.use_axis_loss:
                self.writer.add_scalar('axis_loss', losses['axis'].item(), self.step + self.resume_step)

        if imgs is not None:
            gt_mesh_on_source_img = draw_mesh_on_warp(np.array(imgs["source_img"].permute(1, 2, 0).cpu().detach()),
                                                      imgs["gt_mesh"])
            mesh_on_source_img = draw_mesh_on_warp(np.array(imgs["source_img"].permute(1, 2, 0).cpu().detach()),
                                                   imgs["source_mesh"])
            warped_source_img = F.grid_sample(imgs["source_img"].unsqueeze(0),
                                              imgs["tps_flow"].unsqueeze(0).permute(0, 2, 3, 1), mode='bilinear',
                                              align_corners=True)
            self.writer.add_image('gt_mesh_on_source_img', gt_mesh_on_source_img.transpose((2, 0, 1)) / 255,
                                  self.step + self.resume_step)
            self.writer.add_image('mesh_on_source_img', mesh_on_source_img.transpose((2, 0, 1)) / 255,
                                  self.step + self.resume_step)
            self.writer.add_image('warped_source_img', warped_source_img.squeeze().cpu().detach(),
                                  self.step + self.resume_step)

    def save(self):
        def save_checkpoint(rate, params):
            state_dict = self._master_params_to_state_dict(params)
            logger.log(f"Saving model (rate: {rate})...")
            if not rate:
                filename = f"model{(self.step + self.resume_step):06d}.pt"
            else:
                filename = f"ema_{rate}_{(self.step + self.resume_step):06d}.pt"

            torch.save(state_dict, '{}/{}'.format(bf.join(get_blob_logdir()), filename))

        save_checkpoint(0, self.master_params)
        for rate, params in zip(self.ema_rate, self.ema_params):
            save_checkpoint(rate, params)

        # save optimizer state
        # with bf.BlobFile(
        #         bf.join(get_blob_logdir(), f"opt{(self.step + self.resume_step):06d}.pt"),
        #         "wb",
        # ) as f:
        #     torch.save(self.opt.state_dict(), f)

    def _master_params_to_state_dict(self, master_params):
        if self.use_fp16:
            master_params = unflatten_master_params(
                self.model.parameters(), master_params
            )
        state_dict = self.model.state_dict()
        for i, (name, _value) in enumerate(self.model.named_parameters()):
            assert name in state_dict
            state_dict[name] = master_params[i]
        return state_dict

    def _state_dict_to_master_params(self, state_dict):
        params = [state_dict[name] for name, _ in self.model.named_parameters()]
        if self.use_fp16:
            return make_master_params(params)
        else:
            return params

    # Helper: get current device (GPU if available, else CPU)
    def _get_device(self, cuda_idx=0):
        return torch.device("cuda:{}".format(cuda_idx) if torch.cuda.is_available() else "cpu")

    # Helper: load state dict without distributed logic
    def _load_state_dict(self, path):
        return torch.load(path, map_location=settings.train.device)


def parse_resume_step_from_filename(filename):
    """Parse filenames like 'path/to/modelNNNNNN.pt' to get step count"""
    split = filename.split("model")
    if len(split) < 2:
        return 0
    split1 = split[-1].split(".")[0]
    try:
        return int(split1)
    except ValueError:
        return 0


def get_blob_logdir():
    return os.environ.get("DIFFUSION_BLOB_LOGDIR", logger.get_dir())


def find_resume_checkpoint():
    """No distributed storage logic for single-GPU"""
    return None


def find_ema_checkpoint(main_checkpoint, step, rate):
    if main_checkpoint is None:
        return None
    filename = f"ema_{rate}_{(step):06d}.pt"
    path = bf.join(bf.dirname(main_checkpoint), filename)
    if bf.exists(path):
        return path
    return None


def log_loss_dict(diffusion, ts, losses):
    for key, values in losses.items():
        logger.logkv_mean(key, values.mean().item())
        if ts.dim() == 0:
            ts = ts.unsqueeze(0)
        for sub_t, sub_loss in zip(ts.cpu().numpy(), values.detach().cpu().numpy()):
            # quartile = int(4 * sub_t / diffusion.num_timesteps)
            # logger.logkv_mean(f"{key}_q{quartile}", sub_loss)

            # only report loss at different sample time step here
            logger.logkv_mean(f"{key}_t{sub_t}", sub_loss)
