import os
import torch
import torchvision.transforms as transforms
from torch.utils.data import DataLoader

import datasets
from utils_data.image_transforms import ArrayToTensor

from train_settings.dvd.evaluation import run_evaluation_docunet
from train_settings.dvd.improved_diffusion import logger
from train_settings.dvd.improved_diffusion.script_util import (args_to_dict,
                                                               create_model_and_diffusion,
                                                               model_and_diffusion_defaults)
from train_settings.models.geotr.geotr_core import GeoTr, GeoTr_Seg, GeoTr_Seg_Inf, \
    reload_segmodel, reload_model, Seg

from datasets.doc_dataset.doc_benchmark import Doc_dewarping_Data1
from train_settings.dvd.evaluation import validate

from train_settings.models.geotr.unet_model import UNet
import config.settings as settings
import numpy as np


class WrappedDiffusionModel(torch.nn.Module):
    def __init__(self, model, t, model_kwargs):
        super().__init__()
        self.model = model
        self.t = t
        self.model_kwargs = model_kwargs

    def forward(self, x):
        return self.model(x, self.t, **self.model_kwargs)


def get_parameter_number(net):
    total_num = sum(p.numel() for p in net.parameters())
    trainable_num = sum(p.numel() for p in net.parameters() if p.requires_grad)
    return {'Total': total_num, 'Trainable': trainable_num}


def run():
    print('************')
    print(settings.eval.dataset_name)
    print('************')
    logger.configure(dir="sampling/{}".format(settings.eval.dataset_name))
    logger.log(f"Corruption Disabled. Evaluating on Original {settings.eval.eval_dataset_path}")
    logger.log("Loading model and diffusion...")

    model, diffusion = create_model_and_diffusion(
        device=settings.eval.device)
    setattr(diffusion, "settings", settings)

    # pretrained_dewarp_model = GeoTr(num_attn_layers=6, num_token=(288//8)**2)
    pretrained_dewarp_model = GeoTr_Seg_Inf()
    reload_segmodel(pretrained_dewarp_model.msk, settings.resume.seg_model_path)
    pretrained_dewarp_model.to(settings.eval.device)
    pretrained_dewarp_model.eval()

    if settings.train.use_line_mask:
        pretrained_line_seg_model = UNet(n_channels=3, n_classes=1)
        pretrained_seg_model = Seg()
        line_model_ckpt = torch.load(settings.resume.line_seg_model_path, map_location='cpu')['model']
        pretrained_line_seg_model.load_state_dict(line_model_ckpt, strict=True)
        pretrained_line_seg_model.to(settings.eval.device)
        pretrained_line_seg_model.eval()

        seg_model_ckpt = torch.load(settings.resume.new_seg_model_path, map_location='cpu')['model']
        pretrained_seg_model.load_state_dict(seg_model_ckpt, strict=True)
        pretrained_seg_model.to(settings.eval.device)
        pretrained_seg_model.eval()

    model.cpu().load_state_dict(torch.load(settings.resume.model_path, map_location="cpu"), strict=False)
    logger.log(f"Model loaded with {settings.resume.model_path}")

    model.to(settings.eval.device)
    print(get_parameter_number(model))
    model.eval()

    logger.log("Creating data loader...")
    logger.info('\n:============== Logging Configs ==============')
    print(settings.eval.eval_dataset_path)
    for key, value in settings.resume.__dict__.items():
        if key in ['model_path', 'timestep_respacing']:
            logger.info(f"\t{key}:\t{value}")
    for key, value in settings.eval.__dict__.items():
        if key in ['eval_dataset_path']:
            logger.info(f"\t{key}:\t{value}")
    logger.info(':===============================================\n')

    # print(settings.env.eval_dataset)
    if settings.eval.dataset_name == "docunet" or settings.eval.dataset_name == "dir300" or settings.eval.dataset_name == "anyphoto" or settings.eval.dataset_name == "docreal":
        # 1. Define training and validation datasets
        input_transform = transforms.Compose([ArrayToTensor(get_float=True)])  # only put channel first
        test_set = datasets.Doc_benchmark(
            settings.eval.eval_dataset_path,
            input_transform,
        )

        test_loader = DataLoader(test_set, batch_size=1, shuffle=True,
                                 drop_last=False, num_workers=8)
        logger.info(f"Starting sampling")
        run_evaluation_docunet(
            settings, logger, test_loader, diffusion, model, pretrained_dewarp_model, pretrained_line_seg_model,
            pretrained_seg_model,
            norm_target_mesh=get_norm_target_mesh([settings.model.tps_resolution, settings.model.tps_resolution],
                                                  settings.train.image_size, dataset_name='doc3d'))
        # have different target mesh if train on different dataset (uvdoc or doc3d)
    elif settings.eval.dataset_name == "doc_val":
        val_set = Doc_dewarping_Data1(root_path=settings.eval.eval_dataset_path, transforms=None, resolution=288,
                                      model_setting="doctr")
        val_loader = DataLoader(val_set, batch_size=1, num_workers=4,
                                drop_last=False, pin_memory=True, shuffle=False)
        prec1 = validate(val_loader, pretrained_dewarp_model)

    logger.log("sampling complete")


def get_norm_target_mesh(tps_resolution, img_resolution, dataset_name='doc3d', ):
    H, W = img_resolution
    grid_h = 512
    grid_w = 512
    if dataset_name == 'doc3d':
        grid_h = 512
        grid_w = 512
    elif dataset_name == 'uvdoc':
        grid_h = 89
        grid_w = 61

    B = 1
    grid_indices_row = np.round(0 + (grid_h - 1) * np.linspace(0, 1, tps_resolution[0])).astype(np.int32)
    grid_indices_col = np.round(0 + (grid_w - 1) * np.linspace(0, 1, tps_resolution[1])).astype(np.int32)
    grid_rows = grid_indices_row[:, np.newaxis]
    grid_cols = grid_indices_col[np.newaxis, :]

    rows = np.linspace(0, H - 1, num=grid_h, dtype=np.float32)
    cols = np.linspace(0, W - 1, num=grid_w, dtype=np.float32)
    row_grid, col_grid = np.meshgrid(cols, rows, indexing='xy')
    base = np.stack([row_grid, col_grid], axis=0)
    base = torch.from_numpy(base[np.newaxis, ...]).repeat(B, 1, 1, 1)

    target_mesh = base[:, :, grid_rows, grid_cols]

    norm_target_mesh = target_mesh.clone()
    norm_target_mesh = norm_target_mesh.permute(0, 2, 3, 1)
    mesh_w = norm_target_mesh[..., 0] * 2. / W - 1
    mesh_h = norm_target_mesh[..., 1] * 2. / H - 1
    norm_target_mesh = torch.stack([mesh_w, mesh_h], dim=3)  # [b,16,16,2],[-1,1]
    return norm_target_mesh.to(dtype=torch.float32).to(settings.eval.device)


if __name__ == "__main__":
    run()
