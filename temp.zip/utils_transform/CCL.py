import torch.nn.functional as F
import torch
import torch.nn as nn

"""
compute feature correlation and generate dense correspondence,
use for time-variant diffusion condition
"""


def GMCCL(feature_1, feature_2):
    # normalization
    norm_feature_1 = F.normalize(feature_1, p=2, dim=1)
    norm_feature_2 = F.normalize(feature_2, p=2, dim=1)

    # global correlation
    b, c, h, w = norm_feature_1.shape
    norm_feature_1 = norm_feature_1.view(b, c, -1).permute(0, 2, 1)  # [B, H*W, C]
    norm_feature_2 = norm_feature_2.view(b, c, -1)  # [B, C, H*W]

    # flow from softmax
    # y, x = torch.meshgrid(torch.arange(h), torch.arange(w))  # [H, W]
    # stacks = [x, y]
    # init_grid = torch.stack(stacks, dim=0).float()  # [2, H, W]
    # init_grid = init_grid[None].repeat(b, 1, 1, 1).to(norm_feature_1.device)  # [B, 2, H, W]
    # grid = init_grid.view(b, 2, -1).permute(0, 2, 1)  # [B, H*W, 2]

    correlation = torch.matmul(norm_feature_1, norm_feature_2).view(b, h, w, h, w) / (c ** 0.5)  # [B, H, W, H, W]
    # correlation = torch.matmul(norm_feature_1, norm_feature_2).view(b, h, w, h, w)
    correlation = correlation.view(b, h * w, h * w)  # [B, H*W, H*W]
    softmax_scale = 300
    prob = F.softmax(correlation * softmax_scale, dim=1)  # [B, H*W, H*W]
    prob = prob.view(b, h * w, h, w)  # [B, H*W, H, W]

    channel = prob.size()[1]

    h_one = torch.linspace(0, h - 1, h).to(feature_1.device)
    one1w = torch.ones(1, w).to(feature_1.device)

    h_one = torch.matmul(h_one.unsqueeze(1), one1w)
    h_one = h_one.unsqueeze(0).unsqueeze(0).expand(b, channel, -1, -1)

    w_one = torch.linspace(0, w - 1, w).to(feature_1.device)
    oneh1 = torch.ones(h, 1).to(feature_1.device)

    w_one = torch.matmul(oneh1, w_one.unsqueeze(0))
    w_one = w_one.unsqueeze(0).unsqueeze(0).expand(b, channel, -1, -1)

    c_one = torch.linspace(0, channel - 1, channel).to(feature_1.device)

    c_one = c_one.unsqueeze(0).unsqueeze(2).unsqueeze(3).expand(b, -1, h, w)

    flow_h = prob * (c_one // w - h_one)
    flow_h = torch.sum(flow_h, dim=1, keepdim=True)
    flow_w = prob * (c_one % w - w_one)
    flow_w = torch.sum(flow_w, dim=1, keepdim=True)

    flow = torch.cat([flow_w, flow_h], 1)

    return flow, prob


def coords_grid(b, h, w, homogeneous=False, device=None):
    y, x = torch.meshgrid(torch.arange(h), torch.arange(w))  # [H, W]

    stacks = [x, y]

    if homogeneous:
        ones = torch.ones_like(x)  # [H, W]
        stacks.append(ones)

    grid = torch.stack(stacks, dim=0).float()  # [2, H, W] or [3, H, W]

    grid = grid[None].repeat(b, 1, 1, 1)  # [B, 2, H, W] or [B, 3, H, W]

    if device is not None:
        grid = grid.to(device)

    return grid


def LMCCL(feature_1, feature_2, r=4):
    # normalization
    norm_feature_1 = F.normalize(feature_1, p=2, dim=1)
    norm_feature_2 = F.normalize(feature_2, p=2, dim=1)

    # local correlation
    b, c, h, w = norm_feature_1.shape
    norm_feature_2 = (F.unfold(norm_feature_2, kernel_size=(2 * r + 1, 2 * r + 1), padding=(r, r)).
                      view(b, c, (2 * r + 1) ** 2, h, w))  # [B, C, (2R+1)^2, H, W]
    norm_feature_2 = norm_feature_2.permute(0, 3, 4, 2, 1)
    norm_feature_1 = norm_feature_1.permute(0, 2, 3, 1)

    # flow from softmax
    y, x = torch.meshgrid(torch.arange(-r, r + 1), torch.arange(-r, r + 1))  # [(2R+1), (2R+1)]
    stacks = [x, y]
    init_grid = torch.stack(stacks, dim=0).float()  # [2, (2R+1), (2R+1)]
    init_grid = init_grid[None].repeat(b, 1, 1, 1)  # [B, 2, (2R+1), (2R+1)]
    grid = init_grid.view(b, 2, -1).permute(0, 2, 1).to(norm_feature_1.device)  # [B, (2R+1)^2, 2]

    correlation = torch.einsum('bhwc,bhwkc->bhwk', norm_feature_1, norm_feature_2)
    correlation = correlation.view(b, h, w, (2 * r + 1), (2 * r + 1))  # [B, H, W, (2R+1), (2R+1)]
    correlation = correlation / (c ** 0.5)
    correlation = correlation.view(b, h * w, -1)  # [B, H*W, (2R+1)^2]
    prob = F.softmax(correlation, dim=-1)
    flow = torch.matmul(prob, grid).view(b, h, w, 2).permute(0, 3, 1, 2)

    return flow, prob


def extract_patches(x, kernel=3, stride=1):
    if kernel != 1:
        x = nn.ZeroPad2d(1)(x)
    x = x.permute(0, 2, 3, 1)
    all_patches = x.unfold(1, kernel, stride).unfold(2, kernel, stride)
    return all_patches


def CCL(feature_1, feature_2):
    bs, c, h, w = feature_1.size()

    norm_feature_1 = F.normalize(feature_1, p=2, dim=1)
    norm_feature_2 = F.normalize(feature_2, p=2, dim=1)
    # print(norm_feature_2.size())

    patches = extract_patches(norm_feature_2)
    if torch.cuda.is_available():
        patches = patches.cuda()

    matching_filters = patches.reshape((patches.size()[0], -1, patches.size()[3], patches.size()[4], patches.size()[5]))

    match_vol = []
    for i in range(bs):
        single_match = F.conv2d(norm_feature_1[i].unsqueeze(0), matching_filters[i], padding=1)
        match_vol.append(single_match)

    match_vol = torch.cat(match_vol, 0)
    # print(match_vol .size())

    # scale softmax
    softmax_scale = 10
    match_vol = F.softmax(match_vol * softmax_scale, 1)

    channel = match_vol.size()[1]

    h_one = torch.linspace(0, h - 1, h)
    one1w = torch.ones(1, w)
    if torch.cuda.is_available():
        h_one = h_one.cuda()
        one1w = one1w.cuda()
    h_one = torch.matmul(h_one.unsqueeze(1), one1w)
    h_one = h_one.unsqueeze(0).unsqueeze(0).expand(bs, channel, -1, -1)

    w_one = torch.linspace(0, w - 1, w)
    oneh1 = torch.ones(h, 1)
    if torch.cuda.is_available():
        w_one = w_one.cuda()
        oneh1 = oneh1.cuda()
    w_one = torch.matmul(oneh1, w_one.unsqueeze(0))
    w_one = w_one.unsqueeze(0).unsqueeze(0).expand(bs, channel, -1, -1)

    c_one = torch.linspace(0, channel - 1, channel)
    if torch.cuda.is_available():
        c_one = c_one.cuda()
    c_one = c_one.unsqueeze(0).unsqueeze(2).unsqueeze(3).expand(bs, -1, h, w)

    flow_h = match_vol * (c_one // w - h_one)
    flow_h = torch.sum(flow_h, dim=1, keepdim=True)
    flow_w = match_vol * (c_one % w - w_one)
    flow_w = torch.sum(flow_w, dim=1, keepdim=True)

    feature_flow = torch.cat([flow_w, flow_h], 1)
    # print(flow.size())

    return feature_flow
