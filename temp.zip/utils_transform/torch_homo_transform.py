import torch.nn.functional as F
import torch
import numpy as np




def tps_transformer(U, source, target, out_size, warp_mask=False):
    # transforming an image (U) from target (control points) to source (control points)
    # all the points should be normalized from -1 ~1

    def _meshgrid(height, width, source):
        x_t = torch.matmul(torch.ones([height, 1]), torch.unsqueeze(torch.linspace(-1.0, 1.0, width), 0)).to(
            source.device)
        y_t = torch.matmul(torch.unsqueeze(torch.linspace(-1.0, 1.0, height), 1), torch.ones([1, width])).to(
            source.device)

        x_t_flat = x_t.reshape([1, 1, -1])
        y_t_flat = y_t.reshape([1, 1, -1])

        num_batch = source.size()[0]
        px = torch.unsqueeze(source[:, :, 0], 2).to(source.device)  # [bn, pn, 1]
        py = torch.unsqueeze(source[:, :, 1], 2).to(source.device)  # [bn, pn, 1]

        d2 = torch.square(x_t_flat - px) + torch.square(y_t_flat - py)
        r = d2 * torch.log(d2 + 1e-6)  # [bn, pn, h*w]
        x_t_flat_g = x_t_flat.expand(num_batch, -1, -1)  # [bn, 1, h*w]
        y_t_flat_g = y_t_flat.expand(num_batch, -1, -1)  # [bn, 1, h*w]
        ones = torch.ones_like(x_t_flat_g).to(source.device)  # [bn, 1, h*w]

        grid = torch.cat((ones, x_t_flat_g, y_t_flat_g, r), 1)  # [bn, 3+pn, h*w]

        return grid

    def _transform(T, source, input_dim, out_size):
        num_batch, num_channels, height, width = input_dim.size()

        out_height, out_width = out_size[0], out_size[1]
        grid = _meshgrid(out_height, out_width, source)  # [bn, 3+pn, h*w]

        # transform A x (1, x_t, y_t, r1, r2, ..., rn) -> (x_s, y_s)
        # [bn, 2, pn+3] x [bn, pn+3, h*w] -> [bn, 2, h*w]
        T_g = torch.matmul(T, grid)
        x_s = T_g[:, 0, :]
        y_s = T_g[:, 1, :]
        x_s_flat = x_s.reshape([-1])
        y_s_flat = y_s.reshape([-1])

        # input_transformed = _interpolate(input_dim, x_s_flat, y_s_flat, out_size)
        # output = input_transformed.reshape([num_batch, out_height, out_width, num_channels])
        # output = output.permute(0, 3, 1, 2)

        flow_x = x_s_flat.reshape([num_batch, -1])
        flow_y = y_s_flat.reshape([num_batch, -1])
        tps_flow = torch.stack([flow_x, flow_y], 1).reshape([num_batch, 2, out_height, out_width])
        img_transformed = F.grid_sample(input_dim, tps_flow.permute(0, 2, 3, 1), align_corners=True,
                                        padding_mode='border')
        if warp_mask:
            mask = torch.tensor(torch.ones([num_batch, 1, height, width])).to(img_transformed.device)
            mask_transformed = F.grid_sample(mask, tps_flow.permute(0, 2, 3, 1), align_corners=True,
                                             padding_mode='zeros')
            mask_transformed[mask_transformed < 0.99] = 0
            mask_transformed[mask_transformed > 0] = 1
            output = torch.cat([img_transformed, mask_transformed], dim=1)
            return output, tps_flow
        else:
            return img_transformed, tps_flow

    def _solve_system(source, target):
        num_batch = source.size()[0]
        num_point = source.size()[1]

        np.set_printoptions(precision=8)

        ones = torch.ones(num_batch, num_point, 1).float().to(source.device)

        p = torch.cat([ones, source], 2)  # [bn, pn, 3]

        p_1 = p.reshape([num_batch, -1, 1, 3])  # [bn, pn, 1, 3]
        p_2 = p.reshape([num_batch, 1, -1, 3])  # [bn, 1, pn, 3]
        d2 = torch.sum(torch.square(p_1 - p_2), 3)  # p1 - p2: [bn, pn, pn, 3]   final output: [bn, pn, pn]

        r = d2 * torch.log(d2 + 1e-6)  # [bn, pn, pn]

        zeros = torch.zeros(num_batch, 3, 3).float().to(source.device)

        W_0 = torch.cat((p, r), 2)  # [bn, pn, 3+pn]
        W_1 = torch.cat((zeros, p.permute(0, 2, 1)), 2)  # [bn, 3, pn+3]
        W = torch.cat((W_0, W_1), 1)  # [bn, pn+3, pn+3]

        W_inv = torch.inverse(W.type(torch.float64))

        zeros2 = torch.zeros(num_batch, 3, 2).to(source.device)

        tp = torch.cat((target, zeros2), 1)  # [bn, pn+3, 2]

        T = torch.matmul(W_inv, tp.type(torch.float64))  # [bn, pn+3, 2]
        T = T.permute(0, 2, 1)  # [bn, 2, pn+3]

        return T.type(torch.float32)

    T = _solve_system(source, target)

    output = _transform(T, source, U, out_size)

    return output


def homo_transformer(U, theta, out_size, warp_mask=False):
    def _meshgrid(height, width, device):
        # mesh (range -1~1)
        x_t = torch.matmul(torch.ones([height, 1]),
                           torch.transpose(torch.unsqueeze(torch.linspace(-1.0, 1.0, width), 1), 1, 0))
        y_t = torch.matmul(torch.unsqueeze(torch.linspace(-1.0, 1.0, height), 1),
                           torch.ones([1, width]))
        # x_t = torch.matmul(torch.ones([height, 1]),
        #                       torch.transpose(torch.unsqueeze(torch.linspace(0.0, width.float(), width), 1), 1, 0))
        # y_t = torch.matmul(torch.unsqueeze(torch.linspace(0.0, height.float(), height), 1),
        #                       torch.ones([1, width]))

        x_t_flat = x_t.reshape((1, -1)).float()
        y_t_flat = y_t.reshape((1, -1)).float()

        ones = torch.ones_like(x_t_flat)
        grid = torch.cat([x_t_flat, y_t_flat, ones], 0).to(device)

        return grid

    def _transform(theta, input_dim, out_size):
        num_batch, num_channels, height, width = input_dim.size()
        #  Changed
        theta = theta.reshape([-1, 3, 3]).float()

        out_height, out_width = out_size[0], out_size[1]
        grid = _meshgrid(out_height, out_width, input_dim.device)
        grid = grid.unsqueeze(0).reshape([1, -1])
        shape = grid.size()
        grid = grid.expand(num_batch, shape[1])
        grid = grid.reshape([num_batch, 3, -1])

        T_g = torch.matmul(theta, grid)
        x_s = T_g[:, 0, :]
        y_s = T_g[:, 1, :]
        t_s = T_g[:, 2, :]

        t_s_flat = t_s.reshape([-1])

        # smaller
        small = 1e-7
        smallers = 1e-6 * (1.0 - torch.ge(torch.abs(t_s_flat), small).float())

        t_s_flat = t_s_flat + smallers
        # condition = torch.sum(torch.gt(torch.abs(t_s_flat), small).float())
        # Ty changed
        x_s_flat = x_s.reshape([-1]) / t_s_flat
        y_s_flat = y_s.reshape([-1]) / t_s_flat

        # input_transformed = _interpolate(input_dim, x_s_flat, y_s_flat, out_size)
        # output = input_transformed.reshape([num_batch, out_height, out_width, num_channels])
        # output = output.permute(0, 3, 1, 2)

        flow_x = x_s_flat.reshape([num_batch, -1])
        flow_y = y_s_flat.reshape([num_batch, -1])
        homo_flow = torch.stack([flow_x, flow_y], 1).reshape([num_batch, 2, out_height, out_width])
        img_transformed = F.grid_sample(input_dim, homo_flow.permute(0, 2, 3, 1), align_corners=True,
                                        padding_mode='border')
        if warp_mask:
            mask = torch.tensor(torch.ones([num_batch, 1, height, width])).to(img_transformed.device)
            mask_transformed = F.grid_sample(mask, homo_flow.permute(0, 2, 3, 1), align_corners=True,
                                             padding_mode='zeros')
            mask_transformed[mask_transformed < 0.99] = 0
            mask_transformed[mask_transformed > 0] = 1
            output = torch.cat([img_transformed, mask_transformed], dim=1)
            return output, homo_flow
        else:
            return img_transformed, homo_flow

    output = _transform(theta, U, out_size)
    return output  # , condition


def H2Mesh(H, rigid_mesh, grid_h, grid_w, device):
    ori_pt = rigid_mesh.reshape(rigid_mesh.size()[0], -1, 2).to(device)
    ones = torch.ones(rigid_mesh.size()[0], (grid_h + 1) * (grid_w + 1), 1).to(device)

    ori_pt = torch.cat((ori_pt, ones), 2)  # bs*(grid_h+1)*(grid_w+1)*3
    tar_pt = torch.matmul(H, ori_pt.permute(0, 2, 1))  # bs*3*(grid_h+1)*(grid_w+1)

    mesh_x = torch.unsqueeze(tar_pt[:, 0, :] / tar_pt[:, 2, :], 2)
    mesh_y = torch.unsqueeze(tar_pt[:, 1, :] / tar_pt[:, 2, :], 2)
    mesh = torch.cat((mesh_x, mesh_y), 2).reshape([rigid_mesh.size()[0], grid_h + 1, grid_w + 1, 2])

    return mesh


# get rigid mesh
def get_rigid_mesh(batch_size, height, width, grid_h, grid_w, device):
    ww = torch.matmul(torch.ones([grid_h + 1, 1]), torch.unsqueeze(torch.linspace(0., float(width), grid_w + 1), 0)).to(
        device)
    hh = torch.matmul(torch.unsqueeze(torch.linspace(0.0, float(height), grid_h + 1), 1),
                      torch.ones([1, grid_w + 1])).to(device)

    ori_pt = torch.cat((ww.unsqueeze(2), hh.unsqueeze(2)), 2)  # (grid_h+1)*(grid_w+1)*2
    ori_pt = ori_pt.unsqueeze(0).expand(batch_size, -1, -1, -1)

    return ori_pt


def get_norm_mesh(mesh, height, width):
    batch_size = mesh.size()[0]
    mesh_w = mesh[..., 0] * 2. / float(width) - 1.
    mesh_h = mesh[..., 1] * 2. / float(height) - 1.
    norm_mesh = torch.stack([mesh_w, mesh_h], 3)  # bs*(grid_h+1)*(grid_w+1)*2

    return norm_mesh.reshape([batch_size, -1, 2])  # bs*-1*2


def warp_with_flow(img, flow):
    # initilize grid_coord
    batch, C, H, W = img.shape
    coords0 = torch.meshgrid(torch.arange(H).cuda(), torch.arange(W).cuda())
    coords0 = torch.stack(coords0[::-1], dim=0).float()
    coords0 = coords0[None].repeat(batch, 1, 1, 1)  # bs, 2, h, w

    # target coordinates
    target_coord = coords0 + flow

    # normalization
    target_coord_w = target_coord[:, 0, :, :] * 2. / float(W) - 1.
    target_coord_h = target_coord[:, 1, :, :] * 2. / float(H) - 1.
    target_coord_wh = torch.stack([target_coord_w, target_coord_h], 1)

    # warp
    warped_img = F.grid_sample(img, target_coord_wh.permute(0, 2, 3, 1), align_corners=True)

    return warped_img
