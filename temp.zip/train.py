import os
import sys

import numpy as np
import torch
import torchvision.transforms as transforms
from termcolor import colored

# from datasets.load_pre_made_dataset import \
#     Doc_Dataset, Aug_Doc_Dataset, Doc3d_Dataset, Mix_Dataset
from datasets.load_pre_made_dataset import \
    Doc_Dataset, Aug_Doc_Dataset, Doc3d_Dataset, Doc3d_Dataset_TPSGen, UVDoc_Dataset_TPSGen, Doc3dGrid_Dataset_TPSGen
from datasets.batch_processing import GLUNetBatchPreprocessing
from utils_data.image_transforms import ArrayToTensor
from utils_data.loaders import Loader
from train_settings.models.geotr.geotr_core import GeoTr, GeoTr_Seg, GeoTr_Seg_womask, GeoTr_Seg_Inf, \
    reload_segmodel, reload_model, Seg

from train_settings.models.geotr.unet_model import UNet

from train_settings.dvd.improved_diffusion import dist_util, logger
from train_settings.dvd.improved_diffusion.resample import create_named_schedule_sampler
from train_settings.dvd.improved_diffusion.script_util import args_to_dict, create_model_and_diffusion, \
    model_and_diffusion_defaults
from train_settings.dvd.improved_diffusion.train_util import TrainLoop
import config.settings as settings

np.set_printoptions(sys.maxsize)


def run():
    if settings.train.ddp:
        dist_util.setup_dist()
        torch.cuda.set_device(dist_util.dev())
    else:
        torch.cuda.set_device(settings.train.device)
    logger.configure(dir="checkpoints/{}_{}".format(settings.train.train_mode, settings.train.dataset_name))

    logger.log("creating model and diffusion...")
    if settings.train.ddp:
        model, diffusion = create_model_and_diffusion(device=dist_util.dev())
    else:
        model, diffusion = create_model_and_diffusion(device=settings.train.device)

    # print(model)
    if settings.log.resume_checkpoint:
        if settings.train.ddp:
            state_dict = dist_util.load_state_dict(settings.log.resume_checkpoint, map_location='cpu')
            model.load_state_dict(state_dict, strict=False)
        else:
            model.load_state_dict(torch.load(settings.log.resume_checkpoint, map_location="cpu"))
            print('load checkpoint from: {}'.format(settings.log.resume_checkpoint))


    print(f"Setting device to {settings.train.device}")
    model = model.to(settings.train.device)

    schedule_sampler = create_named_schedule_sampler(settings.train.schedule_sampler, diffusion)

    pretrained_line_seg_model = UNet(n_channels=3, n_classes=1)
    pretrained_seg_model = Seg()

    # freeze the foreground and text-line segmentation network
    if settings.train.ddp:
        line_model_ckpt = dist_util.load_state_dict(settings.resume.line_seg_model_path, map_location='cpu')['model']
        pretrained_line_seg_model.load_state_dict(line_model_ckpt, strict=True)
        pretrained_line_seg_model.to(dist_util.dev())
        pretrained_line_seg_model.eval()

        seg_model_ckpt = dist_util.load_state_dict(settings.resume.new_seg_model_path, map_location='cpu')['model']
        pretrained_seg_model.load_state_dict(seg_model_ckpt, strict=True)
        pretrained_seg_model.to(dist_util.dev())
        pretrained_seg_model.eval()
    else:
        line_model_ckpt = torch.load(settings.resume.line_seg_model_path, map_location="cpu")['model']
        pretrained_line_seg_model.load_state_dict(line_model_ckpt, strict=True)
        pretrained_line_seg_model.to(settings.train.device)
        pretrained_line_seg_model.eval()

        seg_model_ckpt = torch.load(settings.resume.new_seg_model_path, map_location="cpu")['model']
        pretrained_seg_model.load_state_dict(seg_model_ckpt, strict=True)
        pretrained_seg_model.to(settings.train.device)
        pretrained_seg_model.eval()

    logger.log("creating data loader...")

    # 1. Define training and validation datasets
    # datasets, pre-processing of the images is done within the network function !
    if settings.train.dataset_name == 'doc_debug':
        img_transforms = transforms.Compose([ArrayToTensor(get_float=False)])
        flow_transform = transforms.Compose([ArrayToTensor()])  # just put channels first and put it to float
        train_dataset, _ = Doc_Dataset(root=settings.train.train_dataset_path,
                                       source_image_transform=img_transforms,
                                       target_image_transform=None,
                                       flow_transform=flow_transform,
                                       split=1,
                                       get_mapping=False)
        train_loader = Loader('train', train_dataset, batch_size=settings.train.batch_size, shuffle=True,
                              drop_last=False, training=True, num_workers=settings.train.n_threads)
    elif settings.train.dataset_name == 'uvdoc':
        img_transforms = transforms.Compose([ArrayToTensor(get_float=False)])
        flow_transform = transforms.Compose([ArrayToTensor()])  # just put channels first and put it to float
        train_dataset, _ = UVDoc_Dataset_TPSGen(root=settings.train.train_dataset_path,
                                                source_image_transform=img_transforms,
                                                target_image_transform=None,
                                                flow_transform=flow_transform,
                                                split=1,
                                                get_mapping=False)
    elif settings.train.dataset_name == 'doc3d':
        img_transforms = transforms.Compose([ArrayToTensor(get_float=False)])
        flow_transform = transforms.Compose([ArrayToTensor()])  # just put channels first and put it to float
        train_dataset, _ = Doc3d_Dataset_TPSGen(root=settings.train.train_dataset_path,
                                                source_image_transform=img_transforms,
                                                target_image_transform=None,
                                                flow_transform=flow_transform,
                                                split=1,
                                                get_mapping=False)
    elif settings.train.dataset_name == 'doc3d_grid':
        img_transforms = transforms.Compose([ArrayToTensor(get_float=False)])
        flow_transform = transforms.Compose([ArrayToTensor()])  # just put channels first and put it to float
        train_dataset, _ = Doc3dGrid_Dataset_TPSGen(root=settings.train.train_dataset_path,
                                                source_image_transform=img_transforms,
                                                target_image_transform=None,
                                                flow_transform=flow_transform,
                                                split=1,
                                                get_mapping=False)

    train_loader = Loader('train', train_dataset, batch_size=settings.train.batch_size, shuffle=False,
                          drop_last=False, training=True, num_workers=settings.train.n_threads)

    # Setting dataset name into diffusion because of the semantic setting.
    setattr(diffusion, 'dataset', settings.train.dataset_name)

    # but better results are obtained with using simple bilinear interpolation instead of deconvolutions.
    print(colored('==> ', 'blue') + 'model created.')

    logger.log("training...")
    batch_preprocessing = GLUNetBatchPreprocessing(settings, apply_mask=False, apply_mask_zero_borders=False,
                                                   sparse_ground_truth=False)

    # 4. Define loss module    
    TrainLoop(
        model=model,
        pretrained_dewarp_model=pretrained_seg_model,
        pretrained_line_seg_model=pretrained_line_seg_model,
        diffusion=diffusion,
        settings=settings,
        schedule_sampler=schedule_sampler,
        batch_preprocessing=batch_preprocessing,
        data=train_loader).run_loop_dewarping()


if __name__ == "__main__":
    run()
